/**
 * Formularreferenz.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package at.chipkarte.client.fus.soap;

public class Formularreferenz  implements java.io.Serializable {
    private at.chipkarte.client.fus.soap.Formularcodegruppe formularcode;

    private java.lang.String formulardatum;

    private java.lang.String formulartyp;

    private java.lang.Boolean korrekturMoeglich;

    private at.chipkarte.client.base.soap.SvPersonV2 svPatient;

    public Formularreferenz() {
    }

    public Formularreferenz(
           at.chipkarte.client.fus.soap.Formularcodegruppe formularcode,
           java.lang.String formulardatum,
           java.lang.String formulartyp,
           java.lang.Boolean korrekturMoeglich,
           at.chipkarte.client.base.soap.SvPersonV2 svPatient) {
           this.formularcode = formularcode;
           this.formulardatum = formulardatum;
           this.formulartyp = formulartyp;
           this.korrekturMoeglich = korrekturMoeglich;
           this.svPatient = svPatient;
    }


    /**
     * Gets the formularcode value for this Formularreferenz.
     * 
     * @return formularcode
     */
    public at.chipkarte.client.fus.soap.Formularcodegruppe getFormularcode() {
        return formularcode;
    }


    /**
     * Sets the formularcode value for this Formularreferenz.
     * 
     * @param formularcode
     */
    public void setFormularcode(at.chipkarte.client.fus.soap.Formularcodegruppe formularcode) {
        this.formularcode = formularcode;
    }


    /**
     * Gets the formulardatum value for this Formularreferenz.
     * 
     * @return formulardatum
     */
    public java.lang.String getFormulardatum() {
        return formulardatum;
    }


    /**
     * Sets the formulardatum value for this Formularreferenz.
     * 
     * @param formulardatum
     */
    public void setFormulardatum(java.lang.String formulardatum) {
        this.formulardatum = formulardatum;
    }


    /**
     * Gets the formulartyp value for this Formularreferenz.
     * 
     * @return formulartyp
     */
    public java.lang.String getFormulartyp() {
        return formulartyp;
    }


    /**
     * Sets the formulartyp value for this Formularreferenz.
     * 
     * @param formulartyp
     */
    public void setFormulartyp(java.lang.String formulartyp) {
        this.formulartyp = formulartyp;
    }


    /**
     * Gets the korrekturMoeglich value for this Formularreferenz.
     * 
     * @return korrekturMoeglich
     */
    public java.lang.Boolean getKorrekturMoeglich() {
        return korrekturMoeglich;
    }


    /**
     * Sets the korrekturMoeglich value for this Formularreferenz.
     * 
     * @param korrekturMoeglich
     */
    public void setKorrekturMoeglich(java.lang.Boolean korrekturMoeglich) {
        this.korrekturMoeglich = korrekturMoeglich;
    }


    /**
     * Gets the svPatient value for this Formularreferenz.
     * 
     * @return svPatient
     */
    public at.chipkarte.client.base.soap.SvPersonV2 getSvPatient() {
        return svPatient;
    }


    /**
     * Sets the svPatient value for this Formularreferenz.
     * 
     * @param svPatient
     */
    public void setSvPatient(at.chipkarte.client.base.soap.SvPersonV2 svPatient) {
        this.svPatient = svPatient;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Formularreferenz)) return false;
        Formularreferenz other = (Formularreferenz) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.formularcode==null && other.getFormularcode()==null) || 
             (this.formularcode!=null &&
              this.formularcode.equals(other.getFormularcode()))) &&
            ((this.formulardatum==null && other.getFormulardatum()==null) || 
             (this.formulardatum!=null &&
              this.formulardatum.equals(other.getFormulardatum()))) &&
            ((this.formulartyp==null && other.getFormulartyp()==null) || 
             (this.formulartyp!=null &&
              this.formulartyp.equals(other.getFormulartyp()))) &&
            ((this.korrekturMoeglich==null && other.getKorrekturMoeglich()==null) || 
             (this.korrekturMoeglich!=null &&
              this.korrekturMoeglich.equals(other.getKorrekturMoeglich()))) &&
            ((this.svPatient==null && other.getSvPatient()==null) || 
             (this.svPatient!=null &&
              this.svPatient.equals(other.getSvPatient())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getFormularcode() != null) {
            _hashCode += getFormularcode().hashCode();
        }
        if (getFormulardatum() != null) {
            _hashCode += getFormulardatum().hashCode();
        }
        if (getFormulartyp() != null) {
            _hashCode += getFormulartyp().hashCode();
        }
        if (getKorrekturMoeglich() != null) {
            _hashCode += getKorrekturMoeglich().hashCode();
        }
        if (getSvPatient() != null) {
            _hashCode += getSvPatient().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Formularreferenz.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "formularreferenz"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("formularcode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "formularcode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "formularcodegruppe"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("formulardatum");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "formulardatum"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("formulartyp");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "formulartyp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("korrekturMoeglich");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "korrekturMoeglich"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("svPatient");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "svPatient"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://soap.base.client.chipkarte.at", "svPersonV2"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
