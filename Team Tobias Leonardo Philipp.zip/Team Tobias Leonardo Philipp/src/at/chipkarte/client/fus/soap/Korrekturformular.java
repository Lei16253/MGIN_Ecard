/**
 * Korrekturformular.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package at.chipkarte.client.fus.soap;

public class Korrekturformular  implements java.io.Serializable {
    private at.chipkarte.client.fus.soap.AibDaten aib;

    private at.chipkarte.client.fus.soap.AkbDaten akb;

    private at.chipkarte.client.fus.soap.Dateiinfo[] attachmentInfo;

    private at.chipkarte.client.fus.soap.BibDaten bib;

    private at.chipkarte.client.fus.soap.BkiDaten bki;

    private java.lang.String formulartyp;

    private java.lang.String korrekturart;

    private at.chipkarte.client.fus.soap.RibDaten rib;

    private at.chipkarte.client.fus.soap.RkbDaten rkb;

    public Korrekturformular() {
    }

    public Korrekturformular(
           at.chipkarte.client.fus.soap.AibDaten aib,
           at.chipkarte.client.fus.soap.AkbDaten akb,
           at.chipkarte.client.fus.soap.Dateiinfo[] attachmentInfo,
           at.chipkarte.client.fus.soap.BibDaten bib,
           at.chipkarte.client.fus.soap.BkiDaten bki,
           java.lang.String formulartyp,
           java.lang.String korrekturart,
           at.chipkarte.client.fus.soap.RibDaten rib,
           at.chipkarte.client.fus.soap.RkbDaten rkb) {
           this.aib = aib;
           this.akb = akb;
           this.attachmentInfo = attachmentInfo;
           this.bib = bib;
           this.bki = bki;
           this.formulartyp = formulartyp;
           this.korrekturart = korrekturart;
           this.rib = rib;
           this.rkb = rkb;
    }


    /**
     * Gets the aib value for this Korrekturformular.
     * 
     * @return aib
     */
    public at.chipkarte.client.fus.soap.AibDaten getAib() {
        return aib;
    }


    /**
     * Sets the aib value for this Korrekturformular.
     * 
     * @param aib
     */
    public void setAib(at.chipkarte.client.fus.soap.AibDaten aib) {
        this.aib = aib;
    }


    /**
     * Gets the akb value for this Korrekturformular.
     * 
     * @return akb
     */
    public at.chipkarte.client.fus.soap.AkbDaten getAkb() {
        return akb;
    }


    /**
     * Sets the akb value for this Korrekturformular.
     * 
     * @param akb
     */
    public void setAkb(at.chipkarte.client.fus.soap.AkbDaten akb) {
        this.akb = akb;
    }


    /**
     * Gets the attachmentInfo value for this Korrekturformular.
     * 
     * @return attachmentInfo
     */
    public at.chipkarte.client.fus.soap.Dateiinfo[] getAttachmentInfo() {
        return attachmentInfo;
    }


    /**
     * Sets the attachmentInfo value for this Korrekturformular.
     * 
     * @param attachmentInfo
     */
    public void setAttachmentInfo(at.chipkarte.client.fus.soap.Dateiinfo[] attachmentInfo) {
        this.attachmentInfo = attachmentInfo;
    }


    /**
     * Gets the bib value for this Korrekturformular.
     * 
     * @return bib
     */
    public at.chipkarte.client.fus.soap.BibDaten getBib() {
        return bib;
    }


    /**
     * Sets the bib value for this Korrekturformular.
     * 
     * @param bib
     */
    public void setBib(at.chipkarte.client.fus.soap.BibDaten bib) {
        this.bib = bib;
    }


    /**
     * Gets the bki value for this Korrekturformular.
     * 
     * @return bki
     */
    public at.chipkarte.client.fus.soap.BkiDaten getBki() {
        return bki;
    }


    /**
     * Sets the bki value for this Korrekturformular.
     * 
     * @param bki
     */
    public void setBki(at.chipkarte.client.fus.soap.BkiDaten bki) {
        this.bki = bki;
    }


    /**
     * Gets the formulartyp value for this Korrekturformular.
     * 
     * @return formulartyp
     */
    public java.lang.String getFormulartyp() {
        return formulartyp;
    }


    /**
     * Sets the formulartyp value for this Korrekturformular.
     * 
     * @param formulartyp
     */
    public void setFormulartyp(java.lang.String formulartyp) {
        this.formulartyp = formulartyp;
    }


    /**
     * Gets the korrekturart value for this Korrekturformular.
     * 
     * @return korrekturart
     */
    public java.lang.String getKorrekturart() {
        return korrekturart;
    }


    /**
     * Sets the korrekturart value for this Korrekturformular.
     * 
     * @param korrekturart
     */
    public void setKorrekturart(java.lang.String korrekturart) {
        this.korrekturart = korrekturart;
    }


    /**
     * Gets the rib value for this Korrekturformular.
     * 
     * @return rib
     */
    public at.chipkarte.client.fus.soap.RibDaten getRib() {
        return rib;
    }


    /**
     * Sets the rib value for this Korrekturformular.
     * 
     * @param rib
     */
    public void setRib(at.chipkarte.client.fus.soap.RibDaten rib) {
        this.rib = rib;
    }


    /**
     * Gets the rkb value for this Korrekturformular.
     * 
     * @return rkb
     */
    public at.chipkarte.client.fus.soap.RkbDaten getRkb() {
        return rkb;
    }


    /**
     * Sets the rkb value for this Korrekturformular.
     * 
     * @param rkb
     */
    public void setRkb(at.chipkarte.client.fus.soap.RkbDaten rkb) {
        this.rkb = rkb;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Korrekturformular)) return false;
        Korrekturformular other = (Korrekturformular) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.aib==null && other.getAib()==null) || 
             (this.aib!=null &&
              this.aib.equals(other.getAib()))) &&
            ((this.akb==null && other.getAkb()==null) || 
             (this.akb!=null &&
              this.akb.equals(other.getAkb()))) &&
            ((this.attachmentInfo==null && other.getAttachmentInfo()==null) || 
             (this.attachmentInfo!=null &&
              java.util.Arrays.equals(this.attachmentInfo, other.getAttachmentInfo()))) &&
            ((this.bib==null && other.getBib()==null) || 
             (this.bib!=null &&
              this.bib.equals(other.getBib()))) &&
            ((this.bki==null && other.getBki()==null) || 
             (this.bki!=null &&
              this.bki.equals(other.getBki()))) &&
            ((this.formulartyp==null && other.getFormulartyp()==null) || 
             (this.formulartyp!=null &&
              this.formulartyp.equals(other.getFormulartyp()))) &&
            ((this.korrekturart==null && other.getKorrekturart()==null) || 
             (this.korrekturart!=null &&
              this.korrekturart.equals(other.getKorrekturart()))) &&
            ((this.rib==null && other.getRib()==null) || 
             (this.rib!=null &&
              this.rib.equals(other.getRib()))) &&
            ((this.rkb==null && other.getRkb()==null) || 
             (this.rkb!=null &&
              this.rkb.equals(other.getRkb())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAib() != null) {
            _hashCode += getAib().hashCode();
        }
        if (getAkb() != null) {
            _hashCode += getAkb().hashCode();
        }
        if (getAttachmentInfo() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAttachmentInfo());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAttachmentInfo(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getBib() != null) {
            _hashCode += getBib().hashCode();
        }
        if (getBki() != null) {
            _hashCode += getBki().hashCode();
        }
        if (getFormulartyp() != null) {
            _hashCode += getFormulartyp().hashCode();
        }
        if (getKorrekturart() != null) {
            _hashCode += getKorrekturart().hashCode();
        }
        if (getRib() != null) {
            _hashCode += getRib().hashCode();
        }
        if (getRkb() != null) {
            _hashCode += getRkb().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Korrekturformular.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "korrekturformular"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("aib");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "aib"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "aibDaten"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("akb");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "akb"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "akbDaten"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachmentInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "attachmentInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "dateiinfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "dateiinfos"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bib");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "bib"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "bibDaten"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bki");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "bki"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "bkiDaten"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("formulartyp");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "formulartyp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("korrekturart");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "korrekturart"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rib");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "rib"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "ribDaten"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rkb");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "rkb"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "rkbDaten"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
