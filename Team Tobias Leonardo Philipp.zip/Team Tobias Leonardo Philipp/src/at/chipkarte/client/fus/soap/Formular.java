/**
 * Formular.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package at.chipkarte.client.fus.soap;

public class Formular  implements java.io.Serializable {
    private at.chipkarte.client.fus.soap.AibDaten aib;

    private at.chipkarte.client.fus.soap.AkbDaten akb;

    private at.chipkarte.client.fus.soap.Dateiinfo[] attachmentInfo;

    private at.chipkarte.client.fus.soap.BibDaten bib;

    private at.chipkarte.client.fus.soap.BkiDaten bki;

    private byte[] druckaufbereitung;

    private java.lang.String formuardatum;

    private at.chipkarte.client.fus.soap.Formularcodegruppe formularcode;

    private java.lang.String formulartyp;

    private at.chipkarte.client.fus.soap.Konsultation konsultation;

    private at.chipkarte.client.fus.soap.RibDaten rib;

    private at.chipkarte.client.fus.soap.RkbDaten rkb;

    private at.chipkarte.client.base.soap.SvPersonV2 svPatient;

    private at.chipkarte.client.fus.soap.WpBehandlungsdaten wpBehandlungsdaten;

    public Formular() {
    }

    public Formular(
           at.chipkarte.client.fus.soap.AibDaten aib,
           at.chipkarte.client.fus.soap.AkbDaten akb,
           at.chipkarte.client.fus.soap.Dateiinfo[] attachmentInfo,
           at.chipkarte.client.fus.soap.BibDaten bib,
           at.chipkarte.client.fus.soap.BkiDaten bki,
           byte[] druckaufbereitung,
           java.lang.String formuardatum,
           at.chipkarte.client.fus.soap.Formularcodegruppe formularcode,
           java.lang.String formulartyp,
           at.chipkarte.client.fus.soap.Konsultation konsultation,
           at.chipkarte.client.fus.soap.RibDaten rib,
           at.chipkarte.client.fus.soap.RkbDaten rkb,
           at.chipkarte.client.base.soap.SvPersonV2 svPatient,
           at.chipkarte.client.fus.soap.WpBehandlungsdaten wpBehandlungsdaten) {
           this.aib = aib;
           this.akb = akb;
           this.attachmentInfo = attachmentInfo;
           this.bib = bib;
           this.bki = bki;
           this.druckaufbereitung = druckaufbereitung;
           this.formuardatum = formuardatum;
           this.formularcode = formularcode;
           this.formulartyp = formulartyp;
           this.konsultation = konsultation;
           this.rib = rib;
           this.rkb = rkb;
           this.svPatient = svPatient;
           this.wpBehandlungsdaten = wpBehandlungsdaten;
    }


    /**
     * Gets the aib value for this Formular.
     * 
     * @return aib
     */
    public at.chipkarte.client.fus.soap.AibDaten getAib() {
        return aib;
    }


    /**
     * Sets the aib value for this Formular.
     * 
     * @param aib
     */
    public void setAib(at.chipkarte.client.fus.soap.AibDaten aib) {
        this.aib = aib;
    }


    /**
     * Gets the akb value for this Formular.
     * 
     * @return akb
     */
    public at.chipkarte.client.fus.soap.AkbDaten getAkb() {
        return akb;
    }


    /**
     * Sets the akb value for this Formular.
     * 
     * @param akb
     */
    public void setAkb(at.chipkarte.client.fus.soap.AkbDaten akb) {
        this.akb = akb;
    }


    /**
     * Gets the attachmentInfo value for this Formular.
     * 
     * @return attachmentInfo
     */
    public at.chipkarte.client.fus.soap.Dateiinfo[] getAttachmentInfo() {
        return attachmentInfo;
    }


    /**
     * Sets the attachmentInfo value for this Formular.
     * 
     * @param attachmentInfo
     */
    public void setAttachmentInfo(at.chipkarte.client.fus.soap.Dateiinfo[] attachmentInfo) {
        this.attachmentInfo = attachmentInfo;
    }


    /**
     * Gets the bib value for this Formular.
     * 
     * @return bib
     */
    public at.chipkarte.client.fus.soap.BibDaten getBib() {
        return bib;
    }


    /**
     * Sets the bib value for this Formular.
     * 
     * @param bib
     */
    public void setBib(at.chipkarte.client.fus.soap.BibDaten bib) {
        this.bib = bib;
    }


    /**
     * Gets the bki value for this Formular.
     * 
     * @return bki
     */
    public at.chipkarte.client.fus.soap.BkiDaten getBki() {
        return bki;
    }


    /**
     * Sets the bki value for this Formular.
     * 
     * @param bki
     */
    public void setBki(at.chipkarte.client.fus.soap.BkiDaten bki) {
        this.bki = bki;
    }


    /**
     * Gets the druckaufbereitung value for this Formular.
     * 
     * @return druckaufbereitung
     */
    public byte[] getDruckaufbereitung() {
        return druckaufbereitung;
    }


    /**
     * Sets the druckaufbereitung value for this Formular.
     * 
     * @param druckaufbereitung
     */
    public void setDruckaufbereitung(byte[] druckaufbereitung) {
        this.druckaufbereitung = druckaufbereitung;
    }


    /**
     * Gets the formuardatum value for this Formular.
     * 
     * @return formuardatum
     */
    public java.lang.String getFormuardatum() {
        return formuardatum;
    }


    /**
     * Sets the formuardatum value for this Formular.
     * 
     * @param formuardatum
     */
    public void setFormuardatum(java.lang.String formuardatum) {
        this.formuardatum = formuardatum;
    }


    /**
     * Gets the formularcode value for this Formular.
     * 
     * @return formularcode
     */
    public at.chipkarte.client.fus.soap.Formularcodegruppe getFormularcode() {
        return formularcode;
    }


    /**
     * Sets the formularcode value for this Formular.
     * 
     * @param formularcode
     */
    public void setFormularcode(at.chipkarte.client.fus.soap.Formularcodegruppe formularcode) {
        this.formularcode = formularcode;
    }


    /**
     * Gets the formulartyp value for this Formular.
     * 
     * @return formulartyp
     */
    public java.lang.String getFormulartyp() {
        return formulartyp;
    }


    /**
     * Sets the formulartyp value for this Formular.
     * 
     * @param formulartyp
     */
    public void setFormulartyp(java.lang.String formulartyp) {
        this.formulartyp = formulartyp;
    }


    /**
     * Gets the konsultation value for this Formular.
     * 
     * @return konsultation
     */
    public at.chipkarte.client.fus.soap.Konsultation getKonsultation() {
        return konsultation;
    }


    /**
     * Sets the konsultation value for this Formular.
     * 
     * @param konsultation
     */
    public void setKonsultation(at.chipkarte.client.fus.soap.Konsultation konsultation) {
        this.konsultation = konsultation;
    }


    /**
     * Gets the rib value for this Formular.
     * 
     * @return rib
     */
    public at.chipkarte.client.fus.soap.RibDaten getRib() {
        return rib;
    }


    /**
     * Sets the rib value for this Formular.
     * 
     * @param rib
     */
    public void setRib(at.chipkarte.client.fus.soap.RibDaten rib) {
        this.rib = rib;
    }


    /**
     * Gets the rkb value for this Formular.
     * 
     * @return rkb
     */
    public at.chipkarte.client.fus.soap.RkbDaten getRkb() {
        return rkb;
    }


    /**
     * Sets the rkb value for this Formular.
     * 
     * @param rkb
     */
    public void setRkb(at.chipkarte.client.fus.soap.RkbDaten rkb) {
        this.rkb = rkb;
    }


    /**
     * Gets the svPatient value for this Formular.
     * 
     * @return svPatient
     */
    public at.chipkarte.client.base.soap.SvPersonV2 getSvPatient() {
        return svPatient;
    }


    /**
     * Sets the svPatient value for this Formular.
     * 
     * @param svPatient
     */
    public void setSvPatient(at.chipkarte.client.base.soap.SvPersonV2 svPatient) {
        this.svPatient = svPatient;
    }


    /**
     * Gets the wpBehandlungsdaten value for this Formular.
     * 
     * @return wpBehandlungsdaten
     */
    public at.chipkarte.client.fus.soap.WpBehandlungsdaten getWpBehandlungsdaten() {
        return wpBehandlungsdaten;
    }


    /**
     * Sets the wpBehandlungsdaten value for this Formular.
     * 
     * @param wpBehandlungsdaten
     */
    public void setWpBehandlungsdaten(at.chipkarte.client.fus.soap.WpBehandlungsdaten wpBehandlungsdaten) {
        this.wpBehandlungsdaten = wpBehandlungsdaten;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Formular)) return false;
        Formular other = (Formular) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.aib==null && other.getAib()==null) || 
             (this.aib!=null &&
              this.aib.equals(other.getAib()))) &&
            ((this.akb==null && other.getAkb()==null) || 
             (this.akb!=null &&
              this.akb.equals(other.getAkb()))) &&
            ((this.attachmentInfo==null && other.getAttachmentInfo()==null) || 
             (this.attachmentInfo!=null &&
              java.util.Arrays.equals(this.attachmentInfo, other.getAttachmentInfo()))) &&
            ((this.bib==null && other.getBib()==null) || 
             (this.bib!=null &&
              this.bib.equals(other.getBib()))) &&
            ((this.bki==null && other.getBki()==null) || 
             (this.bki!=null &&
              this.bki.equals(other.getBki()))) &&
            ((this.druckaufbereitung==null && other.getDruckaufbereitung()==null) || 
             (this.druckaufbereitung!=null &&
              java.util.Arrays.equals(this.druckaufbereitung, other.getDruckaufbereitung()))) &&
            ((this.formuardatum==null && other.getFormuardatum()==null) || 
             (this.formuardatum!=null &&
              this.formuardatum.equals(other.getFormuardatum()))) &&
            ((this.formularcode==null && other.getFormularcode()==null) || 
             (this.formularcode!=null &&
              this.formularcode.equals(other.getFormularcode()))) &&
            ((this.formulartyp==null && other.getFormulartyp()==null) || 
             (this.formulartyp!=null &&
              this.formulartyp.equals(other.getFormulartyp()))) &&
            ((this.konsultation==null && other.getKonsultation()==null) || 
             (this.konsultation!=null &&
              this.konsultation.equals(other.getKonsultation()))) &&
            ((this.rib==null && other.getRib()==null) || 
             (this.rib!=null &&
              this.rib.equals(other.getRib()))) &&
            ((this.rkb==null && other.getRkb()==null) || 
             (this.rkb!=null &&
              this.rkb.equals(other.getRkb()))) &&
            ((this.svPatient==null && other.getSvPatient()==null) || 
             (this.svPatient!=null &&
              this.svPatient.equals(other.getSvPatient()))) &&
            ((this.wpBehandlungsdaten==null && other.getWpBehandlungsdaten()==null) || 
             (this.wpBehandlungsdaten!=null &&
              this.wpBehandlungsdaten.equals(other.getWpBehandlungsdaten())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAib() != null) {
            _hashCode += getAib().hashCode();
        }
        if (getAkb() != null) {
            _hashCode += getAkb().hashCode();
        }
        if (getAttachmentInfo() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAttachmentInfo());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAttachmentInfo(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getBib() != null) {
            _hashCode += getBib().hashCode();
        }
        if (getBki() != null) {
            _hashCode += getBki().hashCode();
        }
        if (getDruckaufbereitung() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDruckaufbereitung());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDruckaufbereitung(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getFormuardatum() != null) {
            _hashCode += getFormuardatum().hashCode();
        }
        if (getFormularcode() != null) {
            _hashCode += getFormularcode().hashCode();
        }
        if (getFormulartyp() != null) {
            _hashCode += getFormulartyp().hashCode();
        }
        if (getKonsultation() != null) {
            _hashCode += getKonsultation().hashCode();
        }
        if (getRib() != null) {
            _hashCode += getRib().hashCode();
        }
        if (getRkb() != null) {
            _hashCode += getRkb().hashCode();
        }
        if (getSvPatient() != null) {
            _hashCode += getSvPatient().hashCode();
        }
        if (getWpBehandlungsdaten() != null) {
            _hashCode += getWpBehandlungsdaten().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Formular.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "formular"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("aib");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "aib"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "aibDaten"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("akb");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "akb"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "akbDaten"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachmentInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "attachmentInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "dateiinfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "dateiinfos"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bib");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "bib"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "bibDaten"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bki");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "bki"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "bkiDaten"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("druckaufbereitung");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "druckaufbereitung"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("formuardatum");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "formuardatum"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("formularcode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "formularcode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "formularcodegruppe"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("formulartyp");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "formulartyp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("konsultation");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "konsultation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "konsultation"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rib");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "rib"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "ribDaten"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rkb");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "rkb"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "rkbDaten"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("svPatient");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "svPatient"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://soap.base.client.chipkarte.at", "svPersonV2"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("wpBehandlungsdaten");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "wpBehandlungsdaten"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "wpBehandlungsdaten"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
