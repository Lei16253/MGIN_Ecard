/**
 * Formularinfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package at.chipkarte.client.fus.soap;

public class Formularinfo  implements java.io.Serializable {
    private java.lang.Boolean anlagenMoeglich;

    private java.lang.String formulartyp;

    public Formularinfo() {
    }

    public Formularinfo(
           java.lang.Boolean anlagenMoeglich,
           java.lang.String formulartyp) {
           this.anlagenMoeglich = anlagenMoeglich;
           this.formulartyp = formulartyp;
    }


    /**
     * Gets the anlagenMoeglich value for this Formularinfo.
     * 
     * @return anlagenMoeglich
     */
    public java.lang.Boolean getAnlagenMoeglich() {
        return anlagenMoeglich;
    }


    /**
     * Sets the anlagenMoeglich value for this Formularinfo.
     * 
     * @param anlagenMoeglich
     */
    public void setAnlagenMoeglich(java.lang.Boolean anlagenMoeglich) {
        this.anlagenMoeglich = anlagenMoeglich;
    }


    /**
     * Gets the formulartyp value for this Formularinfo.
     * 
     * @return formulartyp
     */
    public java.lang.String getFormulartyp() {
        return formulartyp;
    }


    /**
     * Sets the formulartyp value for this Formularinfo.
     * 
     * @param formulartyp
     */
    public void setFormulartyp(java.lang.String formulartyp) {
        this.formulartyp = formulartyp;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Formularinfo)) return false;
        Formularinfo other = (Formularinfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.anlagenMoeglich==null && other.getAnlagenMoeglich()==null) || 
             (this.anlagenMoeglich!=null &&
              this.anlagenMoeglich.equals(other.getAnlagenMoeglich()))) &&
            ((this.formulartyp==null && other.getFormulartyp()==null) || 
             (this.formulartyp!=null &&
              this.formulartyp.equals(other.getFormulartyp())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAnlagenMoeglich() != null) {
            _hashCode += getAnlagenMoeglich().hashCode();
        }
        if (getFormulartyp() != null) {
            _hashCode += getFormulartyp().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Formularinfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "formularinfo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("anlagenMoeglich");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "anlagenMoeglich"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("formulartyp");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "formulartyp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
