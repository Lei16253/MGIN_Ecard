/**
 * AkbDaten.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package at.chipkarte.client.fus.soap;

public class AkbDaten  implements java.io.Serializable {
    private java.lang.String behandlungsende;

    private java.lang.String endeGrund;

    private java.lang.String medAngaben;

    public AkbDaten() {
    }

    public AkbDaten(
           java.lang.String behandlungsende,
           java.lang.String endeGrund,
           java.lang.String medAngaben) {
           this.behandlungsende = behandlungsende;
           this.endeGrund = endeGrund;
           this.medAngaben = medAngaben;
    }


    /**
     * Gets the behandlungsende value for this AkbDaten.
     * 
     * @return behandlungsende
     */
    public java.lang.String getBehandlungsende() {
        return behandlungsende;
    }


    /**
     * Sets the behandlungsende value for this AkbDaten.
     * 
     * @param behandlungsende
     */
    public void setBehandlungsende(java.lang.String behandlungsende) {
        this.behandlungsende = behandlungsende;
    }


    /**
     * Gets the endeGrund value for this AkbDaten.
     * 
     * @return endeGrund
     */
    public java.lang.String getEndeGrund() {
        return endeGrund;
    }


    /**
     * Sets the endeGrund value for this AkbDaten.
     * 
     * @param endeGrund
     */
    public void setEndeGrund(java.lang.String endeGrund) {
        this.endeGrund = endeGrund;
    }


    /**
     * Gets the medAngaben value for this AkbDaten.
     * 
     * @return medAngaben
     */
    public java.lang.String getMedAngaben() {
        return medAngaben;
    }


    /**
     * Sets the medAngaben value for this AkbDaten.
     * 
     * @param medAngaben
     */
    public void setMedAngaben(java.lang.String medAngaben) {
        this.medAngaben = medAngaben;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AkbDaten)) return false;
        AkbDaten other = (AkbDaten) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.behandlungsende==null && other.getBehandlungsende()==null) || 
             (this.behandlungsende!=null &&
              this.behandlungsende.equals(other.getBehandlungsende()))) &&
            ((this.endeGrund==null && other.getEndeGrund()==null) || 
             (this.endeGrund!=null &&
              this.endeGrund.equals(other.getEndeGrund()))) &&
            ((this.medAngaben==null && other.getMedAngaben()==null) || 
             (this.medAngaben!=null &&
              this.medAngaben.equals(other.getMedAngaben())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getBehandlungsende() != null) {
            _hashCode += getBehandlungsende().hashCode();
        }
        if (getEndeGrund() != null) {
            _hashCode += getEndeGrund().hashCode();
        }
        if (getMedAngaben() != null) {
            _hashCode += getMedAngaben().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AkbDaten.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "akbDaten"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("behandlungsende");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "behandlungsende"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("endeGrund");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "endeGrund"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("medAngaben");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "medAngaben"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
