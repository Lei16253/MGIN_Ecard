/**
 * Erstformular.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package at.chipkarte.client.fus.soap;

public class Erstformular  implements java.io.Serializable {
    private at.chipkarte.client.fus.soap.AibDaten aib;

    private at.chipkarte.client.fus.soap.AkbDaten akb;

    private at.chipkarte.client.fus.soap.Dateiinfo[] attachmentInfo;

    private at.chipkarte.client.fus.soap.BibDaten bib;

    private at.chipkarte.client.fus.soap.BkiDaten bki;

    private java.lang.String formulartyp;

    private java.lang.Long konsultationId;

    private java.lang.Integer konsultationVersion;

    private at.chipkarte.client.fus.soap.RibDaten rib;

    private at.chipkarte.client.fus.soap.RkbDaten rkb;

    private java.lang.String svNummer;

    public Erstformular() {
    }

    public Erstformular(
           at.chipkarte.client.fus.soap.AibDaten aib,
           at.chipkarte.client.fus.soap.AkbDaten akb,
           at.chipkarte.client.fus.soap.Dateiinfo[] attachmentInfo,
           at.chipkarte.client.fus.soap.BibDaten bib,
           at.chipkarte.client.fus.soap.BkiDaten bki,
           java.lang.String formulartyp,
           java.lang.Long konsultationId,
           java.lang.Integer konsultationVersion,
           at.chipkarte.client.fus.soap.RibDaten rib,
           at.chipkarte.client.fus.soap.RkbDaten rkb,
           java.lang.String svNummer) {
           this.aib = aib;
           this.akb = akb;
           this.attachmentInfo = attachmentInfo;
           this.bib = bib;
           this.bki = bki;
           this.formulartyp = formulartyp;
           this.konsultationId = konsultationId;
           this.konsultationVersion = konsultationVersion;
           this.rib = rib;
           this.rkb = rkb;
           this.svNummer = svNummer;
    }


    /**
     * Gets the aib value for this Erstformular.
     * 
     * @return aib
     */
    public at.chipkarte.client.fus.soap.AibDaten getAib() {
        return aib;
    }


    /**
     * Sets the aib value for this Erstformular.
     * 
     * @param aib
     */
    public void setAib(at.chipkarte.client.fus.soap.AibDaten aib) {
        this.aib = aib;
    }


    /**
     * Gets the akb value for this Erstformular.
     * 
     * @return akb
     */
    public at.chipkarte.client.fus.soap.AkbDaten getAkb() {
        return akb;
    }


    /**
     * Sets the akb value for this Erstformular.
     * 
     * @param akb
     */
    public void setAkb(at.chipkarte.client.fus.soap.AkbDaten akb) {
        this.akb = akb;
    }


    /**
     * Gets the attachmentInfo value for this Erstformular.
     * 
     * @return attachmentInfo
     */
    public at.chipkarte.client.fus.soap.Dateiinfo[] getAttachmentInfo() {
        return attachmentInfo;
    }


    /**
     * Sets the attachmentInfo value for this Erstformular.
     * 
     * @param attachmentInfo
     */
    public void setAttachmentInfo(at.chipkarte.client.fus.soap.Dateiinfo[] attachmentInfo) {
        this.attachmentInfo = attachmentInfo;
    }


    /**
     * Gets the bib value for this Erstformular.
     * 
     * @return bib
     */
    public at.chipkarte.client.fus.soap.BibDaten getBib() {
        return bib;
    }


    /**
     * Sets the bib value for this Erstformular.
     * 
     * @param bib
     */
    public void setBib(at.chipkarte.client.fus.soap.BibDaten bib) {
        this.bib = bib;
    }


    /**
     * Gets the bki value for this Erstformular.
     * 
     * @return bki
     */
    public at.chipkarte.client.fus.soap.BkiDaten getBki() {
        return bki;
    }


    /**
     * Sets the bki value for this Erstformular.
     * 
     * @param bki
     */
    public void setBki(at.chipkarte.client.fus.soap.BkiDaten bki) {
        this.bki = bki;
    }


    /**
     * Gets the formulartyp value for this Erstformular.
     * 
     * @return formulartyp
     */
    public java.lang.String getFormulartyp() {
        return formulartyp;
    }


    /**
     * Sets the formulartyp value for this Erstformular.
     * 
     * @param formulartyp
     */
    public void setFormulartyp(java.lang.String formulartyp) {
        this.formulartyp = formulartyp;
    }


    /**
     * Gets the konsultationId value for this Erstformular.
     * 
     * @return konsultationId
     */
    public java.lang.Long getKonsultationId() {
        return konsultationId;
    }


    /**
     * Sets the konsultationId value for this Erstformular.
     * 
     * @param konsultationId
     */
    public void setKonsultationId(java.lang.Long konsultationId) {
        this.konsultationId = konsultationId;
    }


    /**
     * Gets the konsultationVersion value for this Erstformular.
     * 
     * @return konsultationVersion
     */
    public java.lang.Integer getKonsultationVersion() {
        return konsultationVersion;
    }


    /**
     * Sets the konsultationVersion value for this Erstformular.
     * 
     * @param konsultationVersion
     */
    public void setKonsultationVersion(java.lang.Integer konsultationVersion) {
        this.konsultationVersion = konsultationVersion;
    }


    /**
     * Gets the rib value for this Erstformular.
     * 
     * @return rib
     */
    public at.chipkarte.client.fus.soap.RibDaten getRib() {
        return rib;
    }


    /**
     * Sets the rib value for this Erstformular.
     * 
     * @param rib
     */
    public void setRib(at.chipkarte.client.fus.soap.RibDaten rib) {
        this.rib = rib;
    }


    /**
     * Gets the rkb value for this Erstformular.
     * 
     * @return rkb
     */
    public at.chipkarte.client.fus.soap.RkbDaten getRkb() {
        return rkb;
    }


    /**
     * Sets the rkb value for this Erstformular.
     * 
     * @param rkb
     */
    public void setRkb(at.chipkarte.client.fus.soap.RkbDaten rkb) {
        this.rkb = rkb;
    }


    /**
     * Gets the svNummer value for this Erstformular.
     * 
     * @return svNummer
     */
    public java.lang.String getSvNummer() {
        return svNummer;
    }


    /**
     * Sets the svNummer value for this Erstformular.
     * 
     * @param svNummer
     */
    public void setSvNummer(java.lang.String svNummer) {
        this.svNummer = svNummer;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Erstformular)) return false;
        Erstformular other = (Erstformular) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.aib==null && other.getAib()==null) || 
             (this.aib!=null &&
              this.aib.equals(other.getAib()))) &&
            ((this.akb==null && other.getAkb()==null) || 
             (this.akb!=null &&
              this.akb.equals(other.getAkb()))) &&
            ((this.attachmentInfo==null && other.getAttachmentInfo()==null) || 
             (this.attachmentInfo!=null &&
              java.util.Arrays.equals(this.attachmentInfo, other.getAttachmentInfo()))) &&
            ((this.bib==null && other.getBib()==null) || 
             (this.bib!=null &&
              this.bib.equals(other.getBib()))) &&
            ((this.bki==null && other.getBki()==null) || 
             (this.bki!=null &&
              this.bki.equals(other.getBki()))) &&
            ((this.formulartyp==null && other.getFormulartyp()==null) || 
             (this.formulartyp!=null &&
              this.formulartyp.equals(other.getFormulartyp()))) &&
            ((this.konsultationId==null && other.getKonsultationId()==null) || 
             (this.konsultationId!=null &&
              this.konsultationId.equals(other.getKonsultationId()))) &&
            ((this.konsultationVersion==null && other.getKonsultationVersion()==null) || 
             (this.konsultationVersion!=null &&
              this.konsultationVersion.equals(other.getKonsultationVersion()))) &&
            ((this.rib==null && other.getRib()==null) || 
             (this.rib!=null &&
              this.rib.equals(other.getRib()))) &&
            ((this.rkb==null && other.getRkb()==null) || 
             (this.rkb!=null &&
              this.rkb.equals(other.getRkb()))) &&
            ((this.svNummer==null && other.getSvNummer()==null) || 
             (this.svNummer!=null &&
              this.svNummer.equals(other.getSvNummer())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAib() != null) {
            _hashCode += getAib().hashCode();
        }
        if (getAkb() != null) {
            _hashCode += getAkb().hashCode();
        }
        if (getAttachmentInfo() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAttachmentInfo());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAttachmentInfo(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getBib() != null) {
            _hashCode += getBib().hashCode();
        }
        if (getBki() != null) {
            _hashCode += getBki().hashCode();
        }
        if (getFormulartyp() != null) {
            _hashCode += getFormulartyp().hashCode();
        }
        if (getKonsultationId() != null) {
            _hashCode += getKonsultationId().hashCode();
        }
        if (getKonsultationVersion() != null) {
            _hashCode += getKonsultationVersion().hashCode();
        }
        if (getRib() != null) {
            _hashCode += getRib().hashCode();
        }
        if (getRkb() != null) {
            _hashCode += getRkb().hashCode();
        }
        if (getSvNummer() != null) {
            _hashCode += getSvNummer().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Erstformular.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "erstformular"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("aib");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "aib"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "aibDaten"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("akb");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "akb"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "akbDaten"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachmentInfo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "attachmentInfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "dateiinfo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "dateiinfos"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bib");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "bib"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "bibDaten"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bki");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "bki"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "bkiDaten"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("formulartyp");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "formulartyp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("konsultationId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "konsultationId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("konsultationVersion");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "konsultationVersion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rib");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "rib"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "ribDaten"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rkb");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "rkb"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "rkbDaten"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("svNummer");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "svNummer"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
