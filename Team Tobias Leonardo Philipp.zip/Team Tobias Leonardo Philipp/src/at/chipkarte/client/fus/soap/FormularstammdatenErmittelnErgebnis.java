/**
 * FormularstammdatenErmittelnErgebnis.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package at.chipkarte.client.fus.soap;

public class FormularstammdatenErmittelnErgebnis  implements java.io.Serializable {
    private at.chipkarte.client.fus.soap.Konsultation[] konsultationen;

    private at.chipkarte.client.base.soap.SvPersonV2 svPatient;

    public FormularstammdatenErmittelnErgebnis() {
    }

    public FormularstammdatenErmittelnErgebnis(
           at.chipkarte.client.fus.soap.Konsultation[] konsultationen,
           at.chipkarte.client.base.soap.SvPersonV2 svPatient) {
           this.konsultationen = konsultationen;
           this.svPatient = svPatient;
    }


    /**
     * Gets the konsultationen value for this FormularstammdatenErmittelnErgebnis.
     * 
     * @return konsultationen
     */
    public at.chipkarte.client.fus.soap.Konsultation[] getKonsultationen() {
        return konsultationen;
    }


    /**
     * Sets the konsultationen value for this FormularstammdatenErmittelnErgebnis.
     * 
     * @param konsultationen
     */
    public void setKonsultationen(at.chipkarte.client.fus.soap.Konsultation[] konsultationen) {
        this.konsultationen = konsultationen;
    }

    public at.chipkarte.client.fus.soap.Konsultation getKonsultationen(int i) {
        return this.konsultationen[i];
    }

    public void setKonsultationen(int i, at.chipkarte.client.fus.soap.Konsultation _value) {
        this.konsultationen[i] = _value;
    }


    /**
     * Gets the svPatient value for this FormularstammdatenErmittelnErgebnis.
     * 
     * @return svPatient
     */
    public at.chipkarte.client.base.soap.SvPersonV2 getSvPatient() {
        return svPatient;
    }


    /**
     * Sets the svPatient value for this FormularstammdatenErmittelnErgebnis.
     * 
     * @param svPatient
     */
    public void setSvPatient(at.chipkarte.client.base.soap.SvPersonV2 svPatient) {
        this.svPatient = svPatient;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof FormularstammdatenErmittelnErgebnis)) return false;
        FormularstammdatenErmittelnErgebnis other = (FormularstammdatenErmittelnErgebnis) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.konsultationen==null && other.getKonsultationen()==null) || 
             (this.konsultationen!=null &&
              java.util.Arrays.equals(this.konsultationen, other.getKonsultationen()))) &&
            ((this.svPatient==null && other.getSvPatient()==null) || 
             (this.svPatient!=null &&
              this.svPatient.equals(other.getSvPatient())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getKonsultationen() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getKonsultationen());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getKonsultationen(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSvPatient() != null) {
            _hashCode += getSvPatient().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(FormularstammdatenErmittelnErgebnis.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "formularstammdatenErmittelnErgebnis"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("konsultationen");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "konsultationen"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "konsultation"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("svPatient");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "svPatient"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://soap.base.client.chipkarte.at", "svPersonV2"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
