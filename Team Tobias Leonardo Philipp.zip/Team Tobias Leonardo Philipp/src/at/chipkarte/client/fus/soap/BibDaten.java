/**
 * BibDaten.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package at.chipkarte.client.fus.soap;

public class BibDaten  implements java.io.Serializable {
    private java.lang.String befunddatum;

    private java.lang.String behandlungsplan;

    private java.lang.String eingliederung;

    private java.lang.String erfolgsannahme;

    private java.lang.String[] indikationIB;

    private java.lang.String iotnBib;

    private java.lang.String[] lokalisationFehlbildung;

    public BibDaten() {
    }

    public BibDaten(
           java.lang.String befunddatum,
           java.lang.String behandlungsplan,
           java.lang.String eingliederung,
           java.lang.String erfolgsannahme,
           java.lang.String[] indikationIB,
           java.lang.String iotnBib,
           java.lang.String[] lokalisationFehlbildung) {
           this.befunddatum = befunddatum;
           this.behandlungsplan = behandlungsplan;
           this.eingliederung = eingliederung;
           this.erfolgsannahme = erfolgsannahme;
           this.indikationIB = indikationIB;
           this.iotnBib = iotnBib;
           this.lokalisationFehlbildung = lokalisationFehlbildung;
    }


    /**
     * Gets the befunddatum value for this BibDaten.
     * 
     * @return befunddatum
     */
    public java.lang.String getBefunddatum() {
        return befunddatum;
    }


    /**
     * Sets the befunddatum value for this BibDaten.
     * 
     * @param befunddatum
     */
    public void setBefunddatum(java.lang.String befunddatum) {
        this.befunddatum = befunddatum;
    }


    /**
     * Gets the behandlungsplan value for this BibDaten.
     * 
     * @return behandlungsplan
     */
    public java.lang.String getBehandlungsplan() {
        return behandlungsplan;
    }


    /**
     * Sets the behandlungsplan value for this BibDaten.
     * 
     * @param behandlungsplan
     */
    public void setBehandlungsplan(java.lang.String behandlungsplan) {
        this.behandlungsplan = behandlungsplan;
    }


    /**
     * Gets the eingliederung value for this BibDaten.
     * 
     * @return eingliederung
     */
    public java.lang.String getEingliederung() {
        return eingliederung;
    }


    /**
     * Sets the eingliederung value for this BibDaten.
     * 
     * @param eingliederung
     */
    public void setEingliederung(java.lang.String eingliederung) {
        this.eingliederung = eingliederung;
    }


    /**
     * Gets the erfolgsannahme value for this BibDaten.
     * 
     * @return erfolgsannahme
     */
    public java.lang.String getErfolgsannahme() {
        return erfolgsannahme;
    }


    /**
     * Sets the erfolgsannahme value for this BibDaten.
     * 
     * @param erfolgsannahme
     */
    public void setErfolgsannahme(java.lang.String erfolgsannahme) {
        this.erfolgsannahme = erfolgsannahme;
    }


    /**
     * Gets the indikationIB value for this BibDaten.
     * 
     * @return indikationIB
     */
    public java.lang.String[] getIndikationIB() {
        return indikationIB;
    }


    /**
     * Sets the indikationIB value for this BibDaten.
     * 
     * @param indikationIB
     */
    public void setIndikationIB(java.lang.String[] indikationIB) {
        this.indikationIB = indikationIB;
    }

    public java.lang.String getIndikationIB(int i) {
        return this.indikationIB[i];
    }

    public void setIndikationIB(int i, java.lang.String _value) {
        this.indikationIB[i] = _value;
    }


    /**
     * Gets the iotnBib value for this BibDaten.
     * 
     * @return iotnBib
     */
    public java.lang.String getIotnBib() {
        return iotnBib;
    }


    /**
     * Sets the iotnBib value for this BibDaten.
     * 
     * @param iotnBib
     */
    public void setIotnBib(java.lang.String iotnBib) {
        this.iotnBib = iotnBib;
    }


    /**
     * Gets the lokalisationFehlbildung value for this BibDaten.
     * 
     * @return lokalisationFehlbildung
     */
    public java.lang.String[] getLokalisationFehlbildung() {
        return lokalisationFehlbildung;
    }


    /**
     * Sets the lokalisationFehlbildung value for this BibDaten.
     * 
     * @param lokalisationFehlbildung
     */
    public void setLokalisationFehlbildung(java.lang.String[] lokalisationFehlbildung) {
        this.lokalisationFehlbildung = lokalisationFehlbildung;
    }

    public java.lang.String getLokalisationFehlbildung(int i) {
        return this.lokalisationFehlbildung[i];
    }

    public void setLokalisationFehlbildung(int i, java.lang.String _value) {
        this.lokalisationFehlbildung[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof BibDaten)) return false;
        BibDaten other = (BibDaten) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.befunddatum==null && other.getBefunddatum()==null) || 
             (this.befunddatum!=null &&
              this.befunddatum.equals(other.getBefunddatum()))) &&
            ((this.behandlungsplan==null && other.getBehandlungsplan()==null) || 
             (this.behandlungsplan!=null &&
              this.behandlungsplan.equals(other.getBehandlungsplan()))) &&
            ((this.eingliederung==null && other.getEingliederung()==null) || 
             (this.eingliederung!=null &&
              this.eingliederung.equals(other.getEingliederung()))) &&
            ((this.erfolgsannahme==null && other.getErfolgsannahme()==null) || 
             (this.erfolgsannahme!=null &&
              this.erfolgsannahme.equals(other.getErfolgsannahme()))) &&
            ((this.indikationIB==null && other.getIndikationIB()==null) || 
             (this.indikationIB!=null &&
              java.util.Arrays.equals(this.indikationIB, other.getIndikationIB()))) &&
            ((this.iotnBib==null && other.getIotnBib()==null) || 
             (this.iotnBib!=null &&
              this.iotnBib.equals(other.getIotnBib()))) &&
            ((this.lokalisationFehlbildung==null && other.getLokalisationFehlbildung()==null) || 
             (this.lokalisationFehlbildung!=null &&
              java.util.Arrays.equals(this.lokalisationFehlbildung, other.getLokalisationFehlbildung())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getBefunddatum() != null) {
            _hashCode += getBefunddatum().hashCode();
        }
        if (getBehandlungsplan() != null) {
            _hashCode += getBehandlungsplan().hashCode();
        }
        if (getEingliederung() != null) {
            _hashCode += getEingliederung().hashCode();
        }
        if (getErfolgsannahme() != null) {
            _hashCode += getErfolgsannahme().hashCode();
        }
        if (getIndikationIB() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getIndikationIB());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getIndikationIB(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getIotnBib() != null) {
            _hashCode += getIotnBib().hashCode();
        }
        if (getLokalisationFehlbildung() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getLokalisationFehlbildung());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getLokalisationFehlbildung(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(BibDaten.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "bibDaten"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("befunddatum");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "befunddatum"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("behandlungsplan");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "behandlungsplan"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("eingliederung");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "eingliederung"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("erfolgsannahme");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "erfolgsannahme"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indikationIB");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "indikationIB"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("iotnBib");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "iotnBib"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lokalisationFehlbildung");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "lokalisationFehlbildung"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
