/**
 * WpBehandlungsdaten.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package at.chipkarte.client.fus.soap;

public class WpBehandlungsdaten  implements java.io.Serializable {
    private java.lang.String behandlungsdatum;

    private java.lang.String fachgebietscode;

    private java.lang.String kvt;

    public WpBehandlungsdaten() {
    }

    public WpBehandlungsdaten(
           java.lang.String behandlungsdatum,
           java.lang.String fachgebietscode,
           java.lang.String kvt) {
           this.behandlungsdatum = behandlungsdatum;
           this.fachgebietscode = fachgebietscode;
           this.kvt = kvt;
    }


    /**
     * Gets the behandlungsdatum value for this WpBehandlungsdaten.
     * 
     * @return behandlungsdatum
     */
    public java.lang.String getBehandlungsdatum() {
        return behandlungsdatum;
    }


    /**
     * Sets the behandlungsdatum value for this WpBehandlungsdaten.
     * 
     * @param behandlungsdatum
     */
    public void setBehandlungsdatum(java.lang.String behandlungsdatum) {
        this.behandlungsdatum = behandlungsdatum;
    }


    /**
     * Gets the fachgebietscode value for this WpBehandlungsdaten.
     * 
     * @return fachgebietscode
     */
    public java.lang.String getFachgebietscode() {
        return fachgebietscode;
    }


    /**
     * Sets the fachgebietscode value for this WpBehandlungsdaten.
     * 
     * @param fachgebietscode
     */
    public void setFachgebietscode(java.lang.String fachgebietscode) {
        this.fachgebietscode = fachgebietscode;
    }


    /**
     * Gets the kvt value for this WpBehandlungsdaten.
     * 
     * @return kvt
     */
    public java.lang.String getKvt() {
        return kvt;
    }


    /**
     * Sets the kvt value for this WpBehandlungsdaten.
     * 
     * @param kvt
     */
    public void setKvt(java.lang.String kvt) {
        this.kvt = kvt;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof WpBehandlungsdaten)) return false;
        WpBehandlungsdaten other = (WpBehandlungsdaten) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.behandlungsdatum==null && other.getBehandlungsdatum()==null) || 
             (this.behandlungsdatum!=null &&
              this.behandlungsdatum.equals(other.getBehandlungsdatum()))) &&
            ((this.fachgebietscode==null && other.getFachgebietscode()==null) || 
             (this.fachgebietscode!=null &&
              this.fachgebietscode.equals(other.getFachgebietscode()))) &&
            ((this.kvt==null && other.getKvt()==null) || 
             (this.kvt!=null &&
              this.kvt.equals(other.getKvt())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getBehandlungsdatum() != null) {
            _hashCode += getBehandlungsdatum().hashCode();
        }
        if (getFachgebietscode() != null) {
            _hashCode += getFachgebietscode().hashCode();
        }
        if (getKvt() != null) {
            _hashCode += getKvt().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(WpBehandlungsdaten.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "wpBehandlungsdaten"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("behandlungsdatum");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "behandlungsdatum"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fachgebietscode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "fachgebietscode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("kvt");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "kvt"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
