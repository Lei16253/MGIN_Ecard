package at.chipkarte.client.fus.soap;

public class IFusServiceProxy implements at.chipkarte.client.fus.soap.IFusService {
  private String _endpoint = null;
  private at.chipkarte.client.fus.soap.IFusService iFusService = null;
  
  public IFusServiceProxy() {
    _initIFusServiceProxy();
  }
  
  public IFusServiceProxy(String endpoint) {
    _endpoint = endpoint;
    _initIFusServiceProxy();
  }
  
  private void _initIFusServiceProxy() {
    try {
      iFusService = (new at.chipkarte.client.fus.soap.FusServiceLocator()).getfus_2();
      if (iFusService != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)iFusService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)iFusService)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (iFusService != null)
      ((javax.xml.rpc.Stub)iFusService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public at.chipkarte.client.fus.soap.IFusService getIFusService() {
    if (iFusService == null)
      _initIFusServiceProxy();
    return iFusService;
  }
  
  public at.chipkarte.client.base.soap.Property[] checkStatus(java.lang.String dialogId) throws java.rmi.RemoteException, at.chipkarte.client.base.soap.exceptions.AccessExceptionContent, at.chipkarte.client.base.soap.exceptions.ServiceExceptionContent, at.chipkarte.client.base.soap.exceptions.DialogExceptionContent{
    if (iFusService == null)
      _initIFusServiceProxy();
    return iFusService.checkStatus(dialogId);
  }
  
  public at.chipkarte.client.fus.soap.Formularreferenz[] eigeneFormulareAbfragen(java.lang.String dialogId, java.lang.String svNummer, java.lang.String vorname, java.lang.String zuname, java.lang.String formularKennung, java.lang.String formulartyp, java.lang.String anlagenstatus, java.lang.String erstelldatumVon, java.lang.String erstelldatumBis, java.lang.Boolean nurKorrigierbare) throws java.rmi.RemoteException, at.chipkarte.client.base.soap.exceptions.AccessExceptionContent, at.chipkarte.client.fus.soap.exceptions.FusExceptionContent, at.chipkarte.client.base.soap.exceptions.ServiceExceptionContent, at.chipkarte.client.base.soap.exceptions.DialogExceptionContent, at.chipkarte.client.fus.soap.exceptions.FusInvalidParameterExceptionContent{
    if (iFusService == null)
      _initIFusServiceProxy();
    return iFusService.eigeneFormulareAbfragen(dialogId, svNummer, vorname, zuname, formularKennung, formulartyp, anlagenstatus, erstelldatumVon, erstelldatumBis, nurKorrigierbare);
  }
  
  public at.chipkarte.client.fus.soap.Formular formularAbfragen(java.lang.String dialogId, java.lang.String formularCodePrefix) throws java.rmi.RemoteException, at.chipkarte.client.base.soap.exceptions.AccessExceptionContent, at.chipkarte.client.fus.soap.exceptions.FusExceptionContent, at.chipkarte.client.base.soap.exceptions.ServiceExceptionContent, at.chipkarte.client.base.soap.exceptions.DialogExceptionContent, at.chipkarte.client.fus.soap.exceptions.FusInvalidParameterExceptionContent{
    if (iFusService == null)
      _initIFusServiceProxy();
    return iFusService.formularAbfragen(dialogId, formularCodePrefix);
  }
  
  public at.chipkarte.client.fus.soap.Formular formularErfassen(java.lang.String dialogId, java.lang.String cardReaderId, at.chipkarte.client.fus.soap.Erstformular erstformular, byte[] attachments) throws java.rmi.RemoteException, at.chipkarte.client.base.soap.exceptions.AccessExceptionContent, at.chipkarte.client.fus.soap.exceptions.FusExceptionContent, at.chipkarte.client.base.soap.exceptions.ServiceExceptionContent, at.chipkarte.client.base.soap.exceptions.DialogExceptionContent, at.chipkarte.client.fus.soap.exceptions.FusInvalidParameterExceptionContent, at.chipkarte.client.base.soap.exceptions.CardExceptionContent{
    if (iFusService == null)
      _initIFusServiceProxy();
    return iFusService.formularErfassen(dialogId, cardReaderId, erstformular, attachments);
  }
  
  public at.chipkarte.client.fus.soap.Formularinfo[] formularinfoErmitteln(java.lang.String dialogId, java.lang.String formulartyp) throws java.rmi.RemoteException, at.chipkarte.client.base.soap.exceptions.AccessExceptionContent, at.chipkarte.client.base.soap.exceptions.ServiceExceptionContent, at.chipkarte.client.base.soap.exceptions.DialogExceptionContent, at.chipkarte.client.fus.soap.exceptions.FusInvalidParameterExceptionContent{
    if (iFusService == null)
      _initIFusServiceProxy();
    return iFusService.formularinfoErmitteln(dialogId, formulartyp);
  }
  
  public at.chipkarte.client.fus.soap.FormularstammdatenErmittelnErgebnis formularstammdatenErmitteln(java.lang.String dialogId, java.lang.String cardReaderId, java.lang.String svNummer, java.lang.String formulartyp) throws java.rmi.RemoteException, at.chipkarte.client.base.soap.exceptions.AccessExceptionContent, at.chipkarte.client.fus.soap.exceptions.FusExceptionContent, at.chipkarte.client.base.soap.exceptions.ServiceExceptionContent, at.chipkarte.client.base.soap.exceptions.DialogExceptionContent, at.chipkarte.client.fus.soap.exceptions.FusInvalidParameterExceptionContent, at.chipkarte.client.base.soap.exceptions.CardExceptionContent{
    if (iFusService == null)
      _initIFusServiceProxy();
    return iFusService.formularstammdatenErmitteln(dialogId, cardReaderId, svNummer, formulartyp);
  }
  
  public at.chipkarte.client.fus.soap.Formular korrekturSenden(java.lang.String dialogId, at.chipkarte.client.fus.soap.Korrekturformular korrekturformular, java.lang.String formularCodePrefix, byte[] attachments) throws java.rmi.RemoteException, at.chipkarte.client.base.soap.exceptions.AccessExceptionContent, at.chipkarte.client.fus.soap.exceptions.FusExceptionContent, at.chipkarte.client.base.soap.exceptions.ServiceExceptionContent, at.chipkarte.client.base.soap.exceptions.DialogExceptionContent, at.chipkarte.client.fus.soap.exceptions.FusInvalidParameterExceptionContent{
    if (iFusService == null)
      _initIFusServiceProxy();
    return iFusService.korrekturSenden(dialogId, korrekturformular, formularCodePrefix, attachments);
  }
  
  public java.lang.String[] relevanteWpFachgebieteErmitteln(java.lang.String dialogId) throws java.rmi.RemoteException, at.chipkarte.client.base.soap.exceptions.AccessExceptionContent, at.chipkarte.client.fus.soap.exceptions.FusExceptionContent, at.chipkarte.client.base.soap.exceptions.ServiceExceptionContent, at.chipkarte.client.base.soap.exceptions.DialogExceptionContent{
    if (iFusService == null)
      _initIFusServiceProxy();
    return iFusService.relevanteWpFachgebieteErmitteln(dialogId);
  }
  
  public at.chipkarte.client.fus.soap.Formular wpFormularErfassen(java.lang.String dialogId, java.lang.String cardReaderId, at.chipkarte.client.fus.soap.WpErstformular wpErstformular, byte[] attachments) throws java.rmi.RemoteException, at.chipkarte.client.base.soap.exceptions.AccessExceptionContent, at.chipkarte.client.fus.soap.exceptions.FusExceptionContent, at.chipkarte.client.base.soap.exceptions.ServiceExceptionContent, at.chipkarte.client.base.soap.exceptions.DialogExceptionContent, at.chipkarte.client.fus.soap.exceptions.FusInvalidParameterExceptionContent, at.chipkarte.client.base.soap.exceptions.CardExceptionContent{
    if (iFusService == null)
      _initIFusServiceProxy();
    return iFusService.wpFormularErfassen(dialogId, cardReaderId, wpErstformular, attachments);
  }
  
  public at.chipkarte.client.base.soap.SvPersonV2 wpFormularerfassungPruefen(java.lang.String dialogId, java.lang.String cardReaderId, java.lang.String svNummer, java.lang.String formulartyp, java.lang.String fachgebietscode, java.lang.String behandlungsdatum, java.lang.String kvt) throws java.rmi.RemoteException, at.chipkarte.client.base.soap.exceptions.AccessExceptionContent, at.chipkarte.client.fus.soap.exceptions.FusExceptionContent, at.chipkarte.client.base.soap.exceptions.ServiceExceptionContent, at.chipkarte.client.base.soap.exceptions.DialogExceptionContent, at.chipkarte.client.fus.soap.exceptions.FusInvalidParameterExceptionContent, at.chipkarte.client.base.soap.exceptions.CardExceptionContent{
    if (iFusService == null)
      _initIFusServiceProxy();
    return iFusService.wpFormularerfassungPruefen(dialogId, cardReaderId, svNummer, formulartyp, fachgebietscode, behandlungsdatum, kvt);
  }
  
  
}