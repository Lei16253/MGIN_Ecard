/**
 * Konsultation.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package at.chipkarte.client.fus.soap;

public class Konsultation  implements java.io.Serializable {
    private java.lang.String behandlungsdatum;

    private java.lang.String behandlungsfall;

    private java.lang.String fachgebietscode;

    private java.lang.Long konsultationId;

    private java.lang.Integer konsultationVersion;

    private java.lang.String kvtPatient;

    private java.lang.String kvtVerrechnung;

    public Konsultation() {
    }

    public Konsultation(
           java.lang.String behandlungsdatum,
           java.lang.String behandlungsfall,
           java.lang.String fachgebietscode,
           java.lang.Long konsultationId,
           java.lang.Integer konsultationVersion,
           java.lang.String kvtPatient,
           java.lang.String kvtVerrechnung) {
           this.behandlungsdatum = behandlungsdatum;
           this.behandlungsfall = behandlungsfall;
           this.fachgebietscode = fachgebietscode;
           this.konsultationId = konsultationId;
           this.konsultationVersion = konsultationVersion;
           this.kvtPatient = kvtPatient;
           this.kvtVerrechnung = kvtVerrechnung;
    }


    /**
     * Gets the behandlungsdatum value for this Konsultation.
     * 
     * @return behandlungsdatum
     */
    public java.lang.String getBehandlungsdatum() {
        return behandlungsdatum;
    }


    /**
     * Sets the behandlungsdatum value for this Konsultation.
     * 
     * @param behandlungsdatum
     */
    public void setBehandlungsdatum(java.lang.String behandlungsdatum) {
        this.behandlungsdatum = behandlungsdatum;
    }


    /**
     * Gets the behandlungsfall value for this Konsultation.
     * 
     * @return behandlungsfall
     */
    public java.lang.String getBehandlungsfall() {
        return behandlungsfall;
    }


    /**
     * Sets the behandlungsfall value for this Konsultation.
     * 
     * @param behandlungsfall
     */
    public void setBehandlungsfall(java.lang.String behandlungsfall) {
        this.behandlungsfall = behandlungsfall;
    }


    /**
     * Gets the fachgebietscode value for this Konsultation.
     * 
     * @return fachgebietscode
     */
    public java.lang.String getFachgebietscode() {
        return fachgebietscode;
    }


    /**
     * Sets the fachgebietscode value for this Konsultation.
     * 
     * @param fachgebietscode
     */
    public void setFachgebietscode(java.lang.String fachgebietscode) {
        this.fachgebietscode = fachgebietscode;
    }


    /**
     * Gets the konsultationId value for this Konsultation.
     * 
     * @return konsultationId
     */
    public java.lang.Long getKonsultationId() {
        return konsultationId;
    }


    /**
     * Sets the konsultationId value for this Konsultation.
     * 
     * @param konsultationId
     */
    public void setKonsultationId(java.lang.Long konsultationId) {
        this.konsultationId = konsultationId;
    }


    /**
     * Gets the konsultationVersion value for this Konsultation.
     * 
     * @return konsultationVersion
     */
    public java.lang.Integer getKonsultationVersion() {
        return konsultationVersion;
    }


    /**
     * Sets the konsultationVersion value for this Konsultation.
     * 
     * @param konsultationVersion
     */
    public void setKonsultationVersion(java.lang.Integer konsultationVersion) {
        this.konsultationVersion = konsultationVersion;
    }


    /**
     * Gets the kvtPatient value for this Konsultation.
     * 
     * @return kvtPatient
     */
    public java.lang.String getKvtPatient() {
        return kvtPatient;
    }


    /**
     * Sets the kvtPatient value for this Konsultation.
     * 
     * @param kvtPatient
     */
    public void setKvtPatient(java.lang.String kvtPatient) {
        this.kvtPatient = kvtPatient;
    }


    /**
     * Gets the kvtVerrechnung value for this Konsultation.
     * 
     * @return kvtVerrechnung
     */
    public java.lang.String getKvtVerrechnung() {
        return kvtVerrechnung;
    }


    /**
     * Sets the kvtVerrechnung value for this Konsultation.
     * 
     * @param kvtVerrechnung
     */
    public void setKvtVerrechnung(java.lang.String kvtVerrechnung) {
        this.kvtVerrechnung = kvtVerrechnung;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Konsultation)) return false;
        Konsultation other = (Konsultation) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.behandlungsdatum==null && other.getBehandlungsdatum()==null) || 
             (this.behandlungsdatum!=null &&
              this.behandlungsdatum.equals(other.getBehandlungsdatum()))) &&
            ((this.behandlungsfall==null && other.getBehandlungsfall()==null) || 
             (this.behandlungsfall!=null &&
              this.behandlungsfall.equals(other.getBehandlungsfall()))) &&
            ((this.fachgebietscode==null && other.getFachgebietscode()==null) || 
             (this.fachgebietscode!=null &&
              this.fachgebietscode.equals(other.getFachgebietscode()))) &&
            ((this.konsultationId==null && other.getKonsultationId()==null) || 
             (this.konsultationId!=null &&
              this.konsultationId.equals(other.getKonsultationId()))) &&
            ((this.konsultationVersion==null && other.getKonsultationVersion()==null) || 
             (this.konsultationVersion!=null &&
              this.konsultationVersion.equals(other.getKonsultationVersion()))) &&
            ((this.kvtPatient==null && other.getKvtPatient()==null) || 
             (this.kvtPatient!=null &&
              this.kvtPatient.equals(other.getKvtPatient()))) &&
            ((this.kvtVerrechnung==null && other.getKvtVerrechnung()==null) || 
             (this.kvtVerrechnung!=null &&
              this.kvtVerrechnung.equals(other.getKvtVerrechnung())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getBehandlungsdatum() != null) {
            _hashCode += getBehandlungsdatum().hashCode();
        }
        if (getBehandlungsfall() != null) {
            _hashCode += getBehandlungsfall().hashCode();
        }
        if (getFachgebietscode() != null) {
            _hashCode += getFachgebietscode().hashCode();
        }
        if (getKonsultationId() != null) {
            _hashCode += getKonsultationId().hashCode();
        }
        if (getKonsultationVersion() != null) {
            _hashCode += getKonsultationVersion().hashCode();
        }
        if (getKvtPatient() != null) {
            _hashCode += getKvtPatient().hashCode();
        }
        if (getKvtVerrechnung() != null) {
            _hashCode += getKvtVerrechnung().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Konsultation.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "konsultation"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("behandlungsdatum");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "behandlungsdatum"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("behandlungsfall");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "behandlungsfall"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fachgebietscode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "fachgebietscode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("konsultationId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "konsultationId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("konsultationVersion");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "konsultationVersion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("kvtPatient");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "kvtPatient"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("kvtVerrechnung");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "kvtVerrechnung"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
