/**
 * BkiDaten.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package at.chipkarte.client.fus.soap;

public class BkiDaten  implements java.io.Serializable {
    private java.lang.String befunddatum;

    private java.lang.String eingliederung;

    private java.lang.String iotnBki;

    private java.lang.String[] lokalisationFehlbildung;

    private java.lang.String medAngabe;

    public BkiDaten() {
    }

    public BkiDaten(
           java.lang.String befunddatum,
           java.lang.String eingliederung,
           java.lang.String iotnBki,
           java.lang.String[] lokalisationFehlbildung,
           java.lang.String medAngabe) {
           this.befunddatum = befunddatum;
           this.eingliederung = eingliederung;
           this.iotnBki = iotnBki;
           this.lokalisationFehlbildung = lokalisationFehlbildung;
           this.medAngabe = medAngabe;
    }


    /**
     * Gets the befunddatum value for this BkiDaten.
     * 
     * @return befunddatum
     */
    public java.lang.String getBefunddatum() {
        return befunddatum;
    }


    /**
     * Sets the befunddatum value for this BkiDaten.
     * 
     * @param befunddatum
     */
    public void setBefunddatum(java.lang.String befunddatum) {
        this.befunddatum = befunddatum;
    }


    /**
     * Gets the eingliederung value for this BkiDaten.
     * 
     * @return eingliederung
     */
    public java.lang.String getEingliederung() {
        return eingliederung;
    }


    /**
     * Sets the eingliederung value for this BkiDaten.
     * 
     * @param eingliederung
     */
    public void setEingliederung(java.lang.String eingliederung) {
        this.eingliederung = eingliederung;
    }


    /**
     * Gets the iotnBki value for this BkiDaten.
     * 
     * @return iotnBki
     */
    public java.lang.String getIotnBki() {
        return iotnBki;
    }


    /**
     * Sets the iotnBki value for this BkiDaten.
     * 
     * @param iotnBki
     */
    public void setIotnBki(java.lang.String iotnBki) {
        this.iotnBki = iotnBki;
    }


    /**
     * Gets the lokalisationFehlbildung value for this BkiDaten.
     * 
     * @return lokalisationFehlbildung
     */
    public java.lang.String[] getLokalisationFehlbildung() {
        return lokalisationFehlbildung;
    }


    /**
     * Sets the lokalisationFehlbildung value for this BkiDaten.
     * 
     * @param lokalisationFehlbildung
     */
    public void setLokalisationFehlbildung(java.lang.String[] lokalisationFehlbildung) {
        this.lokalisationFehlbildung = lokalisationFehlbildung;
    }

    public java.lang.String getLokalisationFehlbildung(int i) {
        return this.lokalisationFehlbildung[i];
    }

    public void setLokalisationFehlbildung(int i, java.lang.String _value) {
        this.lokalisationFehlbildung[i] = _value;
    }


    /**
     * Gets the medAngabe value for this BkiDaten.
     * 
     * @return medAngabe
     */
    public java.lang.String getMedAngabe() {
        return medAngabe;
    }


    /**
     * Sets the medAngabe value for this BkiDaten.
     * 
     * @param medAngabe
     */
    public void setMedAngabe(java.lang.String medAngabe) {
        this.medAngabe = medAngabe;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof BkiDaten)) return false;
        BkiDaten other = (BkiDaten) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.befunddatum==null && other.getBefunddatum()==null) || 
             (this.befunddatum!=null &&
              this.befunddatum.equals(other.getBefunddatum()))) &&
            ((this.eingliederung==null && other.getEingliederung()==null) || 
             (this.eingliederung!=null &&
              this.eingliederung.equals(other.getEingliederung()))) &&
            ((this.iotnBki==null && other.getIotnBki()==null) || 
             (this.iotnBki!=null &&
              this.iotnBki.equals(other.getIotnBki()))) &&
            ((this.lokalisationFehlbildung==null && other.getLokalisationFehlbildung()==null) || 
             (this.lokalisationFehlbildung!=null &&
              java.util.Arrays.equals(this.lokalisationFehlbildung, other.getLokalisationFehlbildung()))) &&
            ((this.medAngabe==null && other.getMedAngabe()==null) || 
             (this.medAngabe!=null &&
              this.medAngabe.equals(other.getMedAngabe())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getBefunddatum() != null) {
            _hashCode += getBefunddatum().hashCode();
        }
        if (getEingliederung() != null) {
            _hashCode += getEingliederung().hashCode();
        }
        if (getIotnBki() != null) {
            _hashCode += getIotnBki().hashCode();
        }
        if (getLokalisationFehlbildung() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getLokalisationFehlbildung());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getLokalisationFehlbildung(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getMedAngabe() != null) {
            _hashCode += getMedAngabe().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(BkiDaten.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "bkiDaten"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("befunddatum");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "befunddatum"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("eingliederung");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "eingliederung"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("iotnBki");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "iotnBki"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lokalisationFehlbildung");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "lokalisationFehlbildung"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("medAngabe");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "medAngabe"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
