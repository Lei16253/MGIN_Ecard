/**
 * Dateiinfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package at.chipkarte.client.fus.soap;

public class Dateiinfo  implements java.io.Serializable {
    private java.lang.String dateiInhaltstyp;

    private java.lang.String dateiformat;

    private java.lang.Long dateigroesse;

    private java.lang.String dateiname;

    private java.lang.String erfassungszeit;

    private at.chipkarte.client.fus.soap.Formularcodegruppe formularcode;

    private java.lang.String uebertragungsstatus;

    public Dateiinfo() {
    }

    public Dateiinfo(
           java.lang.String dateiInhaltstyp,
           java.lang.String dateiformat,
           java.lang.Long dateigroesse,
           java.lang.String dateiname,
           java.lang.String erfassungszeit,
           at.chipkarte.client.fus.soap.Formularcodegruppe formularcode,
           java.lang.String uebertragungsstatus) {
           this.dateiInhaltstyp = dateiInhaltstyp;
           this.dateiformat = dateiformat;
           this.dateigroesse = dateigroesse;
           this.dateiname = dateiname;
           this.erfassungszeit = erfassungszeit;
           this.formularcode = formularcode;
           this.uebertragungsstatus = uebertragungsstatus;
    }


    /**
     * Gets the dateiInhaltstyp value for this Dateiinfo.
     * 
     * @return dateiInhaltstyp
     */
    public java.lang.String getDateiInhaltstyp() {
        return dateiInhaltstyp;
    }


    /**
     * Sets the dateiInhaltstyp value for this Dateiinfo.
     * 
     * @param dateiInhaltstyp
     */
    public void setDateiInhaltstyp(java.lang.String dateiInhaltstyp) {
        this.dateiInhaltstyp = dateiInhaltstyp;
    }


    /**
     * Gets the dateiformat value for this Dateiinfo.
     * 
     * @return dateiformat
     */
    public java.lang.String getDateiformat() {
        return dateiformat;
    }


    /**
     * Sets the dateiformat value for this Dateiinfo.
     * 
     * @param dateiformat
     */
    public void setDateiformat(java.lang.String dateiformat) {
        this.dateiformat = dateiformat;
    }


    /**
     * Gets the dateigroesse value for this Dateiinfo.
     * 
     * @return dateigroesse
     */
    public java.lang.Long getDateigroesse() {
        return dateigroesse;
    }


    /**
     * Sets the dateigroesse value for this Dateiinfo.
     * 
     * @param dateigroesse
     */
    public void setDateigroesse(java.lang.Long dateigroesse) {
        this.dateigroesse = dateigroesse;
    }


    /**
     * Gets the dateiname value for this Dateiinfo.
     * 
     * @return dateiname
     */
    public java.lang.String getDateiname() {
        return dateiname;
    }


    /**
     * Sets the dateiname value for this Dateiinfo.
     * 
     * @param dateiname
     */
    public void setDateiname(java.lang.String dateiname) {
        this.dateiname = dateiname;
    }


    /**
     * Gets the erfassungszeit value for this Dateiinfo.
     * 
     * @return erfassungszeit
     */
    public java.lang.String getErfassungszeit() {
        return erfassungszeit;
    }


    /**
     * Sets the erfassungszeit value for this Dateiinfo.
     * 
     * @param erfassungszeit
     */
    public void setErfassungszeit(java.lang.String erfassungszeit) {
        this.erfassungszeit = erfassungszeit;
    }


    /**
     * Gets the formularcode value for this Dateiinfo.
     * 
     * @return formularcode
     */
    public at.chipkarte.client.fus.soap.Formularcodegruppe getFormularcode() {
        return formularcode;
    }


    /**
     * Sets the formularcode value for this Dateiinfo.
     * 
     * @param formularcode
     */
    public void setFormularcode(at.chipkarte.client.fus.soap.Formularcodegruppe formularcode) {
        this.formularcode = formularcode;
    }


    /**
     * Gets the uebertragungsstatus value for this Dateiinfo.
     * 
     * @return uebertragungsstatus
     */
    public java.lang.String getUebertragungsstatus() {
        return uebertragungsstatus;
    }


    /**
     * Sets the uebertragungsstatus value for this Dateiinfo.
     * 
     * @param uebertragungsstatus
     */
    public void setUebertragungsstatus(java.lang.String uebertragungsstatus) {
        this.uebertragungsstatus = uebertragungsstatus;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Dateiinfo)) return false;
        Dateiinfo other = (Dateiinfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.dateiInhaltstyp==null && other.getDateiInhaltstyp()==null) || 
             (this.dateiInhaltstyp!=null &&
              this.dateiInhaltstyp.equals(other.getDateiInhaltstyp()))) &&
            ((this.dateiformat==null && other.getDateiformat()==null) || 
             (this.dateiformat!=null &&
              this.dateiformat.equals(other.getDateiformat()))) &&
            ((this.dateigroesse==null && other.getDateigroesse()==null) || 
             (this.dateigroesse!=null &&
              this.dateigroesse.equals(other.getDateigroesse()))) &&
            ((this.dateiname==null && other.getDateiname()==null) || 
             (this.dateiname!=null &&
              this.dateiname.equals(other.getDateiname()))) &&
            ((this.erfassungszeit==null && other.getErfassungszeit()==null) || 
             (this.erfassungszeit!=null &&
              this.erfassungszeit.equals(other.getErfassungszeit()))) &&
            ((this.formularcode==null && other.getFormularcode()==null) || 
             (this.formularcode!=null &&
              this.formularcode.equals(other.getFormularcode()))) &&
            ((this.uebertragungsstatus==null && other.getUebertragungsstatus()==null) || 
             (this.uebertragungsstatus!=null &&
              this.uebertragungsstatus.equals(other.getUebertragungsstatus())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getDateiInhaltstyp() != null) {
            _hashCode += getDateiInhaltstyp().hashCode();
        }
        if (getDateiformat() != null) {
            _hashCode += getDateiformat().hashCode();
        }
        if (getDateigroesse() != null) {
            _hashCode += getDateigroesse().hashCode();
        }
        if (getDateiname() != null) {
            _hashCode += getDateiname().hashCode();
        }
        if (getErfassungszeit() != null) {
            _hashCode += getErfassungszeit().hashCode();
        }
        if (getFormularcode() != null) {
            _hashCode += getFormularcode().hashCode();
        }
        if (getUebertragungsstatus() != null) {
            _hashCode += getUebertragungsstatus().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Dateiinfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "dateiinfo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dateiInhaltstyp");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "dateiInhaltstyp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dateiformat");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "dateiformat"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dateigroesse");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "dateigroesse"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dateiname");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "dateiname"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("erfassungszeit");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "erfassungszeit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("formularcode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "formularcode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "formularcodegruppe"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("uebertragungsstatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "uebertragungsstatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
