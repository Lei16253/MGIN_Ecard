/**
 * Formularcodegruppe.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package at.chipkarte.client.fus.soap;

public class Formularcodegruppe  implements java.io.Serializable {
    private java.lang.String formularCode;

    private java.lang.String formularCodePrefix;

    private java.lang.String formularCodeVersion;

    private java.lang.String formularKennung;

    public Formularcodegruppe() {
    }

    public Formularcodegruppe(
           java.lang.String formularCode,
           java.lang.String formularCodePrefix,
           java.lang.String formularCodeVersion,
           java.lang.String formularKennung) {
           this.formularCode = formularCode;
           this.formularCodePrefix = formularCodePrefix;
           this.formularCodeVersion = formularCodeVersion;
           this.formularKennung = formularKennung;
    }


    /**
     * Gets the formularCode value for this Formularcodegruppe.
     * 
     * @return formularCode
     */
    public java.lang.String getFormularCode() {
        return formularCode;
    }


    /**
     * Sets the formularCode value for this Formularcodegruppe.
     * 
     * @param formularCode
     */
    public void setFormularCode(java.lang.String formularCode) {
        this.formularCode = formularCode;
    }


    /**
     * Gets the formularCodePrefix value for this Formularcodegruppe.
     * 
     * @return formularCodePrefix
     */
    public java.lang.String getFormularCodePrefix() {
        return formularCodePrefix;
    }


    /**
     * Sets the formularCodePrefix value for this Formularcodegruppe.
     * 
     * @param formularCodePrefix
     */
    public void setFormularCodePrefix(java.lang.String formularCodePrefix) {
        this.formularCodePrefix = formularCodePrefix;
    }


    /**
     * Gets the formularCodeVersion value for this Formularcodegruppe.
     * 
     * @return formularCodeVersion
     */
    public java.lang.String getFormularCodeVersion() {
        return formularCodeVersion;
    }


    /**
     * Sets the formularCodeVersion value for this Formularcodegruppe.
     * 
     * @param formularCodeVersion
     */
    public void setFormularCodeVersion(java.lang.String formularCodeVersion) {
        this.formularCodeVersion = formularCodeVersion;
    }


    /**
     * Gets the formularKennung value for this Formularcodegruppe.
     * 
     * @return formularKennung
     */
    public java.lang.String getFormularKennung() {
        return formularKennung;
    }


    /**
     * Sets the formularKennung value for this Formularcodegruppe.
     * 
     * @param formularKennung
     */
    public void setFormularKennung(java.lang.String formularKennung) {
        this.formularKennung = formularKennung;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Formularcodegruppe)) return false;
        Formularcodegruppe other = (Formularcodegruppe) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.formularCode==null && other.getFormularCode()==null) || 
             (this.formularCode!=null &&
              this.formularCode.equals(other.getFormularCode()))) &&
            ((this.formularCodePrefix==null && other.getFormularCodePrefix()==null) || 
             (this.formularCodePrefix!=null &&
              this.formularCodePrefix.equals(other.getFormularCodePrefix()))) &&
            ((this.formularCodeVersion==null && other.getFormularCodeVersion()==null) || 
             (this.formularCodeVersion!=null &&
              this.formularCodeVersion.equals(other.getFormularCodeVersion()))) &&
            ((this.formularKennung==null && other.getFormularKennung()==null) || 
             (this.formularKennung!=null &&
              this.formularKennung.equals(other.getFormularKennung())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getFormularCode() != null) {
            _hashCode += getFormularCode().hashCode();
        }
        if (getFormularCodePrefix() != null) {
            _hashCode += getFormularCodePrefix().hashCode();
        }
        if (getFormularCodeVersion() != null) {
            _hashCode += getFormularCodeVersion().hashCode();
        }
        if (getFormularKennung() != null) {
            _hashCode += getFormularKennung().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Formularcodegruppe.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "formularcodegruppe"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("formularCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "formularCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("formularCodePrefix");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "formularCodePrefix"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("formularCodeVersion");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "formularCodeVersion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("formularKennung");
        elemField.setXmlName(new javax.xml.namespace.QName("http://soap.fus.client.chipkarte.at", "formularKennung"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
