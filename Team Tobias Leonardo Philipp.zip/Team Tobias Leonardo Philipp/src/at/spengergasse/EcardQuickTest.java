package at.spengergasse;

import java.awt.Dialog;

import at.chipkarte.client.base.soap.BaseServiceLocator;
import at.chipkarte.client.base.soap.CardReader;
import at.chipkarte.client.base.soap.IBaseService;
import at.chipkarte.client.base.soap.Ordination;
import at.chipkarte.client.base.soap.ProduktInfo;
import at.chipkarte.client.base.soap.VertragspartnerV2;
import at.chipkarte.client.fus.soap.Konsultation;


public class EcardQuickTest {
	 

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ProduktInfo mproduktinfo = new ProduktInfo();
		BaseServiceLocator bsl = new BaseServiceLocator();
		Konsultation konsultation = new Konsultation();
		long KonsID = 30;
		
		try {
			IBaseService bs = bsl.getbase_15();
			CardReader[] rea = bs.getCardReaders();
			mproduktinfo.setProduktId(3);
			mproduktinfo.setProduktVersion("1");
			
			konsultation.setBehandlungsdatum("21.04.2017");
			konsultation.setBehandlungsfall(null);
			konsultation.setKvtPatient(null);
			konsultation.setKonsultationId(KonsID);
			konsultation.setKonsultationVersion(10);
			konsultation.setKvtVerrechnung(null);
			
			
			
			String d = bs.createDialog(rea[0].getId(), mproduktinfo, null, false);
			
			VertragspartnerV2 vertragspartner = bs.authenticateDialog(d, null, "0000", rea[0].getId());
			Ordination[] ordination = vertragspartner.getOrdination();
			
			bs.setDialogAddress(d, ordination[0].getOrdinationId(), ordination[0].getTaetigkeitsBereich(0).getId(), null, null, null);
			bs.closeDialog(d);
			//System.out.println(vertragspartner.getVorname());
			

			System.out.println("Die Dialog ID lautet: " + d);
			System.out.println("Die Konsultation ist: " + konsultation.getBehandlungsdatum() + " " + konsultation.getKonsultationId());
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
