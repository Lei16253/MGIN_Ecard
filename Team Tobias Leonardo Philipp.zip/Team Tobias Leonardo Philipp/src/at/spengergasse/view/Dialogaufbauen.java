package at.spengergasse.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Label;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import at.chipkarte.client.base.soap.AuthenticationStatus;
import at.chipkarte.client.base.soap.BaseServiceLocator;
import at.chipkarte.client.base.soap.Card;
import at.chipkarte.client.base.soap.CardReader;
import at.chipkarte.client.base.soap.IBaseService;
import at.chipkarte.client.base.soap.Ordination;
import at.chipkarte.client.base.soap.ProduktInfo;
import at.chipkarte.client.base.soap.SvPersonV2;
import at.chipkarte.client.base.soap.VertragspartnerV2;
import at.chipkarte.client.fus.soap.Konsultation;
import at.chipkarte.client.kse.soap.Anspruch;
import at.chipkarte.client.vdas.soap.IVdasService;
import at.chipkarte.client.vdas.soap.VdasServiceLocator;
import at.chipkarte.client.vdas.soap.VersichertendatenAbfrage;
import at.chipkarte.client.vdas.soap.VersichertendatenAbfrageErgebnis;
import at.spengergasse.model.Model_Dialogaufbauen;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import java.awt.Font;
import java.awt.Canvas;

public class Dialogaufbauen extends JDialog {

	private final JPanel contentPanel = new JPanel();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			Dialogaufbauen dialog = new Dialogaufbauen();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	ProduktInfo mproduktinfo = new ProduktInfo();
	Anspruch manspruch = new Anspruch();
	BaseServiceLocator bsl = new BaseServiceLocator();
	VdasServiceLocator vdasl = new VdasServiceLocator();
	Konsultation konsultation = new Konsultation();
	public static Model_Dialogaufbauen newDialogaufbau = new Model_Dialogaufbauen();
	VersichertendatenAbfrage versabfr;
	
	Label lbDialogID;
	JButton btnDialogAufbauen;
	JPanel buttonpane;
	
	JComboBox<String> comboBox = new JComboBox<String>();
	

	/**
	 * Create the dialog.
	 */
	public Dialogaufbauen() {
		setBounds(100, 100, 519, 291);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setForeground(Color.BLACK);
		contentPanel.setBackground(Color.WHITE);
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		comboBox.setBackground(new Color(255, 255, 204));
		
		comboBox.setBounds(106, 88, 166, 20);
		contentPanel.add(comboBox);
		
		try {
			IBaseService bs = bsl.getbase_15();
			CardReader[] rea = bs.getCardReaders();
			mproduktinfo.setProduktId(3);
			System.out.println(mproduktinfo.getProduktId());
			mproduktinfo.setProduktVersion("1");
			comboBox.addItem(rea[0].getId());
			comboBox.addItem(rea[1].getId());
			comboBox.addItem(rea[2].getId());
			newDialogaufbau.setPselectedRea(comboBox.getSelectedItem().toString());
		}catch(Exception d){
		d.printStackTrace();
		}
		
		JButton btnDialogAufbauen = new JButton("Dialog aufbauen");
		btnDialogAufbauen.setBackground(new Color(153, 204, 204));
		btnDialogAufbauen.setForeground(Color.BLACK);
		btnDialogAufbauen.setBounds(33, 174, 131, 77);
		contentPanel.add(btnDialogAufbauen);
		
		JLabel lblReader = new JLabel("Kartenleser");
		lblReader.setForeground(Color.BLACK);
		lblReader.setBounds(18, 90, 91, 14);
		contentPanel.add(lblReader);
		
		JLabel lblNewLabel = new JLabel("Konsultationsverwaltung");
		lblNewLabel.setFont(new Font("Comic Sans MS", Font.PLAIN, 22));
		lblNewLabel.setBounds(18, 23, 290, 35);
		contentPanel.add(lblNewLabel);
		
		ImageIcon logo = new ImageIcon("LogoEcard.png");
		
		JButton button = new JButton(logo);
		button.setBounds(369, 23, 120, 95);
		contentPanel.add(button);
		
		{
			{
				btnDialogAufbauen.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						try {
							Integer produktinfo = 1;
							String produktversion = "1";
							String extUID = "1";
							IBaseService bs = bsl.getbase_15();
							IVdasService vdas = vdasl.getvdas_14();
							CardReader[] rea = bs.getCardReaders();
							
						    
							newDialogaufbau.setPcardid(bs.getCardData(rea[0].getId()));
							newDialogaufbau.setPcin(newDialogaufbau.getPcardid().getCin());
							newDialogaufbau.setPecardnummer(newDialogaufbau.getPcardid().getNummer());
							newDialogaufbau.setPanspruchid(manspruch.getId());
							mproduktinfo.setProduktId(produktinfo);
							mproduktinfo.setProduktVersion(produktversion);
							
							SvPersonV2 person = new SvPersonV2();	
							newDialogaufbau.setPreaId(comboBox.getSelectedItem().toString());
							Card c = bs.getCardData(newDialogaufbau.getPreaId());
							newDialogaufbau.setPvorname(c.getVorname());
							newDialogaufbau.setPnachname(c.getNachname());
							newDialogaufbau.setPsvnummer(person.getSvNummer());
							
							

							newDialogaufbau.setPd(bs.createDialog(newDialogaufbau.getPreaId(), mproduktinfo, extUID, true));
							
							VertragspartnerV2 vertragspartner = bs.authenticateDialog(newDialogaufbau.getPd(), null, "0000", rea[0].getId());
							Ordination[] ordination = vertragspartner.getOrdination();
							
							AuthenticationStatus status = new AuthenticationStatus();
							
							bs.setDialogAddress(newDialogaufbau.getPd(), ordination[0].getOrdinationId(), ordination[0].getTaetigkeitsBereich(0).getId(), null, null, null);
							//bs.closeDialog(d);
							
							btnDialogAufbauen.setBackground(Color.GREEN);
							//lbDialogID.setText(d);
							
							bs.setCardReader(newDialogaufbau.getPd(), newDialogaufbau.getPselectedRea());
							
							System.out.println(status.getFailedLoginAttempts());
							
							
							Konsultationverwalten newWindow = new Konsultationverwalten();
							newWindow.setVisible(true);
							
							
							
					}catch(Exception e){
					e.printStackTrace();
					}}});
				
						
					}
				};
				
			}
		}