package at.spengergasse.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.xml.rpc.ServiceException;

import at.chipkarte.client.base.soap.AuthenticationStatus;
import at.chipkarte.client.base.soap.BaseService;
import at.chipkarte.client.base.soap.BaseServiceLocator;
import at.chipkarte.client.base.soap.CardReader;
import at.chipkarte.client.base.soap.IBaseService;
import at.chipkarte.client.base.soap.Ordination;
import at.chipkarte.client.base.soap.ProduktInfo;
import at.chipkarte.client.base.soap.VertragspartnerV2;
import at.chipkarte.client.base.soap.exceptions.CardExceptionContent;
import at.chipkarte.client.base.soap.exceptions.DialogExceptionContent;
import at.chipkarte.client.base.soap.exceptions.ServiceExceptionContent;
import at.chipkarte.client.fus.soap.Konsultation;
import at.chipkarte.client.kse.soap.ErgebnisKonsultation;
import at.chipkarte.client.kse.soap.IKseService;
import at.chipkarte.client.kse.soap.KseServiceLocator;
import at.chipkarte.client.kse.soap.SuchFilter;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;
import java.awt.Label;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.rmi.RemoteException;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;

public class Konsultationverwalten extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Konsultationverwalten frame = new Konsultationverwalten();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	KseServiceLocator ksl = new KseServiceLocator();
	ProduktInfo mproduktinfo = new ProduktInfo();
	BaseServiceLocator bsl = new BaseServiceLocator();
	Konsultation konsultation = new Konsultation();
	Label lbDialogID;
	private JTextField tfBehandlungsdatum;
	private JTextField tfBehandlungsfall;
	private JTextField tfKvtVerrechnung;
	String Dialogidchange;
	long KonsID;
	int KonsVersion;
	public static String ReaderKonsultation;
	/**
	 * Create the frame.
	 */
	public Konsultationverwalten() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 517, 301);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setForeground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		try {
			IBaseService bs = bsl.getbase_15();
			CardReader[] rea = bs.getCardReaders();
			mproduktinfo.setProduktId(3);
			System.out.println(mproduktinfo.getProduktId());
			mproduktinfo.setProduktVersion("1");
			
				
		}catch(Exception d){
		d.printStackTrace();
		}
		//tfKonsultationID.setText("0");
		
		JLabel lbDialogID = new JLabel("DialogID");
		lbDialogID.setEnabled(false);
		lbDialogID.setFont(new Font("Lucida Bright", Font.PLAIN, 11));
		lbDialogID.setBounds(10, 50, 383, 14);
		contentPane.add(lbDialogID);
		
		JLabel lblNewLabel = new JLabel("Neue Konsultation erfassen");
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setBackground(new Color(0, 0, 128));
		lblNewLabel.setFont(new Font("Lucida Bright", Font.PLAIN, 20));
		lblNewLabel.setBounds(10, 11, 283, 37);
		contentPane.add(lblNewLabel);
		
		tfBehandlungsdatum = new JTextField();
		tfBehandlungsdatum.setForeground(new Color(0, 0, 204));
		tfBehandlungsdatum.setBounds(133, 75, 86, 20);
		contentPane.add(tfBehandlungsdatum);
		tfBehandlungsdatum.setColumns(10);
		
		tfBehandlungsfall = new JTextField();
		tfBehandlungsfall.setForeground(new Color(0, 0, 204));
		tfBehandlungsfall.setColumns(10);
		tfBehandlungsfall.setBounds(133, 106, 86, 20);
		contentPane.add(tfBehandlungsfall);
		//tfKonsultationVersion.setText("0");
		
		tfKvtVerrechnung = new JTextField();
		tfKvtVerrechnung.setForeground(new Color(0, 0, 204));
		tfKvtVerrechnung.setColumns(10);
		tfKvtVerrechnung.setBounds(133, 138, 86, 20);
		contentPane.add(tfKvtVerrechnung);
		
		JLabel lblBehandlungsdatum = new JLabel("Behandlungsdatum");
		lblBehandlungsdatum.setForeground(Color.BLACK);
		lblBehandlungsdatum.setFont(new Font("Lucida Bright", Font.PLAIN, 11));
		lblBehandlungsdatum.setBounds(10, 78, 113, 14);
		contentPane.add(lblBehandlungsdatum);
		
		JLabel lblBehandlungsfall = new JLabel("Behandlungsfall");
		lblBehandlungsfall.setForeground(Color.BLACK);
		lblBehandlungsfall.setFont(new Font("Lucida Bright", Font.PLAIN, 11));
		lblBehandlungsfall.setBounds(10, 109, 113, 14);
		contentPane.add(lblBehandlungsfall);
		
		JLabel lblVerrechnung = new JLabel("Verrechnung");
		lblVerrechnung.setForeground(Color.BLACK);
		lblVerrechnung.setFont(new Font("Lucida Bright", Font.PLAIN, 11));
		lblVerrechnung.setBounds(10, 141, 113, 14);
		contentPane.add(lblVerrechnung);
		
		JButton btnKonsultationAnlegen = new JButton("Konsultation anlegen");
		btnKonsultationAnlegen.setForeground(Color.BLACK);
		btnKonsultationAnlegen.setBackground(new Color(153, 204, 204));
		btnKonsultationAnlegen.setFont(new Font("Lucida Bright", Font.PLAIN, 11));
		btnKonsultationAnlegen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try{
					IKseService fus = ksl.getkse_17();
					
					
					ErgebnisKonsultation konsultation = fus.doKonsultation(Dialogaufbauen.newDialogaufbau.getPcin(), 
							Dialogaufbauen.newDialogaufbau.getPd(), Dialogaufbauen.newDialogaufbau.getPsvnummer(), 
							"111", Dialogaufbauen.newDialogaufbau.getPanspruchid(), "11", "11", "11", "11.11.2016", true, 
							Dialogaufbauen.newDialogaufbau.getPreaId());
					System.out.println(konsultation);
					
					}catch(Exception d){
						d.printStackTrace();
					}
				
				
				System.out.println("Konsultationsdaten eingef�gt!");
			}
		});
		btnKonsultationAnlegen.setBounds(311, 189, 184, 23);
		contentPane.add(btnKonsultationAnlegen);
		
		
		lbDialogID.setText(Dialogaufbauen.newDialogaufbau.getPvorname() + " " + Dialogaufbauen.newDialogaufbau.getPnachname());
		
		ImageIcon start = new ImageIcon("1493135526_search.png");
		
		JButton btnSearch = new JButton(start);
		btnSearch.setForeground(new Color(0, 0, 153));
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Konsultationsuchen newWindow = new Konsultationsuchen();
				newWindow.setVisible(true);
			}
		});
		btnSearch.setBounds(390, 21, 19, 20);
		contentPane.add(btnSearch);
		BaseServiceLocator bsl = new BaseServiceLocator();
		try{
			IBaseService bs = bsl.getbase_15();
		}catch(Exception d){
			d.printStackTrace();
		}
		
		JButton btnDialogBeenden = new JButton("Dialog beenden");
		btnDialogBeenden.setForeground(Color.BLACK);
		btnDialogBeenden.setBackground(new Color(153, 204, 204));
		btnDialogBeenden.setFont(new Font("Lucida Bright", Font.PLAIN, 11));
		btnDialogBeenden.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try{
					IBaseService bs = bsl.getbase_15();
					bs.closeDialog(Dialogaufbauen.d);
				}catch(Exception d){
					d.printStackTrace();
				}
			}
		});
		btnDialogBeenden.setBounds(311, 222, 184, 23);
		contentPane.add(btnDialogBeenden);
		
		
		/*JButton btnDialogSchlieenUnd = new JButton("Dialog schlie\u00DFen und beenden");
		btnDialogSchlieenUnd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Dialogaufbauen.d.closeDialog();
			}
		});
		btnDialogSchlieenUnd.setBounds(240, 170, 167, 20);
		contentPane.add(btnDialogSchlieenUnd);*/

	}
	}

