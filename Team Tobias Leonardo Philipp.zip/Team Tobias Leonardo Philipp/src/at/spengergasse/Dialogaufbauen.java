package at.spengergasse;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Label;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import at.chipkarte.client.base.soap.BaseServiceLocator;
import at.chipkarte.client.base.soap.Card;
import at.chipkarte.client.base.soap.CardReader;
import at.chipkarte.client.base.soap.IBaseService;
import at.chipkarte.client.base.soap.Ordination;
import at.chipkarte.client.base.soap.ProduktInfo;
import at.chipkarte.client.base.soap.VertragspartnerV2;
import at.chipkarte.client.fus.soap.Konsultation;
import at.chipkarte.client.kse.soap.Anspruch;
import at.chipkarte.client.vdas.soap.IVdasService;
import at.chipkarte.client.vdas.soap.VdasServiceLocator;
import at.chipkarte.client.vdas.soap.VersichertendatenAbfrage;
import at.chipkarte.client.vdas.soap.VersichertendatenAbfrageErgebnis;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JRadioButton;

public class Dialogaufbauen extends JDialog {

	private final JPanel contentPanel = new JPanel();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			Dialogaufbauen dialog = new Dialogaufbauen();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	ProduktInfo mproduktinfo = new ProduktInfo();
	Anspruch manspruch = new Anspruch();
	BaseServiceLocator bsl = new BaseServiceLocator();
	VdasServiceLocator vdasl = new VdasServiceLocator();
	Konsultation konsultation = new Konsultation();
	
	public static String d = "";
	public static Card cardid;
	public static String cin;
	public static String ecardnummer = "";
	public static String anspruchid = "";
	public static VersichertendatenAbfrageErgebnis svtid;
	public static String vorname = "";
	public static String nachname = "";
	public static String reaId;
	public static String selectedRea;
	public static String svnummer;
	
	VersichertendatenAbfrage versabfr;
	
	Label lbDialogID;
	JButton btnDialogAufbauen;
	JPanel buttonpane;
	JComboBox<String> comboBox = new JComboBox<String>();
	private JTextField tfProduktinfo;
	private JTextField tfextUID;
	private JTextField tfProduktversion;
	

	/**
	 * Create the dialog.
	 */
	public Dialogaufbauen() {
		setBounds(100, 100, 419, 192);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setForeground(new Color(0, 0, 153));
		contentPanel.setBackground(new Color(255, 255, 204));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		comboBox.setBackground(new Color(255, 255, 204));
		
		comboBox.setBounds(86, 11, 166, 20);
		contentPanel.add(comboBox);
		
		try {
			IBaseService bs = bsl.getbase_15();
			CardReader[] rea = bs.getCardReaders();
			mproduktinfo.setProduktId(3);
			System.out.println(mproduktinfo.getProduktId());
			mproduktinfo.setProduktVersion("1");
			comboBox.addItem(rea[0].getId());
			comboBox.addItem(rea[1].getId());
			comboBox.addItem(rea[2].getId());
			selectedRea = comboBox.getSelectedItem().toString();
			
				
		}catch(Exception d){
		d.printStackTrace();
		}
		
		JButton btnDialogAufbauen = new JButton("Dialog aufbauen");
		btnDialogAufbauen.setBackground(new Color(153, 204, 204));
		btnDialogAufbauen.setForeground(new Color(0, 0, 153));
		btnDialogAufbauen.setBounds(165, 119, 161, 23);
		contentPanel.add(btnDialogAufbauen);
		
		tfProduktinfo = new JTextField();
		tfProduktinfo.setForeground(new Color(0, 0, 153));
		tfProduktinfo.setBounds(86, 42, 34, 20);
		contentPanel.add(tfProduktinfo);
		tfProduktinfo.setColumns(10);
		
		JLabel lblReader = new JLabel("Reader");
		lblReader.setForeground(new Color(0, 0, 153));
		lblReader.setBounds(10, 17, 46, 14);
		contentPanel.add(lblReader);
		
		JLabel lblProduktinfo = new JLabel("Produktinfo");
		lblProduktinfo.setForeground(new Color(0, 0, 153));
		lblProduktinfo.setBounds(10, 45, 66, 14);
		contentPanel.add(lblProduktinfo);
		
		JLabel lblExtuid = new JLabel("extUID");
		lblExtuid.setForeground(new Color(0, 0, 153));
		lblExtuid.setBounds(10, 70, 66, 14);
		contentPanel.add(lblExtuid);
		
		tfextUID = new JTextField();
		tfextUID.setForeground(new Color(0, 0, 153));
		tfextUID.setColumns(10);
		tfextUID.setBounds(86, 67, 34, 20);
		contentPanel.add(tfextUID);
		
		tfProduktversion = new JTextField();
		tfProduktversion.setForeground(new Color(0, 0, 153));
		tfProduktversion.setColumns(10);
		tfProduktversion.setBounds(292, 42, 34, 20);
		contentPanel.add(tfProduktversion);
		
		JLabel lblProduktversion = new JLabel("Produktversion");
		lblProduktversion.setForeground(new Color(0, 0, 153));
		lblProduktversion.setBounds(165, 45, 114, 14);
		contentPanel.add(lblProduktversion);
		
		JLabel lblPushupNotification = new JLabel("Push Notification");
		lblPushupNotification.setForeground(new Color(0, 0, 153));
		lblPushupNotification.setBounds(10, 95, 154, 14);
		contentPanel.add(lblPushupNotification);
		
		JRadioButton rdbtnEnabled = new JRadioButton("Enabled");
		rdbtnEnabled.setForeground(new Color(0, 0, 153));
		rdbtnEnabled.setBackground(new Color(255, 255, 204));
		rdbtnEnabled.setBounds(170, 89, 109, 23);
		contentPanel.add(rdbtnEnabled);
		{
			{
				btnDialogAufbauen.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						try {
							Integer produktinfo = Integer.parseInt(tfProduktinfo.getText());
							String produktversion = tfProduktversion.getText();
							String extUID = tfextUID.getText();
							Boolean pushup = rdbtnEnabled.isSelected();
							IBaseService bs = bsl.getbase_15();
							IVdasService vdas = vdasl.getvdas_14();
							CardReader[] rea = bs.getCardReaders();
							//String stringcard = cardid.toString();
							//svtid = vdas.getVersichertenDaten(Dialogaufbauen.d, versabfr, stringcard);
							//String vdasid = svtid.getVdasId();
							//System.out.println(vdasid);
							
							//read = rea[0].getId().toString();
							
							cardid = bs.getCardData(rea[0].getId());
							cin = cardid.getCin();
							ecardnummer = cardid.getNummer();
							anspruchid = manspruch.getId();
							mproduktinfo.setProduktId(produktinfo);
							mproduktinfo.setProduktVersion(produktversion);
														
							//comboBox.addItem(rea[0].getId());
							//comboBox.addItem(rea[1].getId());
							//comboBox.addItem(rea[2].getId());
							reaId = comboBox.getSelectedItem().toString();
							Card c = bs.getCardData(reaId);
							vorname = c.getVorname();
							nachname = c.getNachname();
							svnummer = c.getNummer();
							
							

							d = bs.createDialog(reaId, mproduktinfo, extUID, pushup);
							
							VertragspartnerV2 vertragspartner = bs.authenticateDialog(d, null, "0000", rea[0].getId());
							Ordination[] ordination = vertragspartner.getOrdination();
							
							
							bs.setDialogAddress(d, ordination[0].getOrdinationId(), ordination[0].getTaetigkeitsBereich(0).getId(), null, null, null);
							//bs.closeDialog(d);
							btnDialogAufbauen.setBackground(Color.GREEN);
							//lbDialogID.setText(d);
							
							
							Konsultationverwalten newWindow = new Konsultationverwalten();
							newWindow.setVisible(true);
							
							
							
					}catch(Exception e){
					e.printStackTrace();
					}}});
				
						
					}
				};
				
			}
		
		}