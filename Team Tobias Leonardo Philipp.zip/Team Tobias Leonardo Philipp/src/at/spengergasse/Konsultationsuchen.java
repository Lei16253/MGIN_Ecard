package at.spengergasse;

import java.awt.EventQueue;

import javax.swing.JDialog;
import javax.swing.JScrollPane;

import at.chipkarte.client.base.soap.BaseServiceLocator;
import at.chipkarte.client.fus.soap.FusServiceLocator;
import at.chipkarte.client.fus.soap.IFusService;
import at.chipkarte.client.fus.soap.Konsultation;
import at.chipkarte.client.kse.soap.IKseService;
import at.chipkarte.client.kse.soap.KonsultationdatenAnfrage;
import at.chipkarte.client.kse.soap.KseServiceLocator;
import at.chipkarte.client.kse.soap.Kse_17BindingStub;
import at.chipkarte.client.kse.soap.SuchFilter;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JTable;
import java.awt.Color;

public class Konsultationsuchen extends JDialog {

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				KonsultationdatenAnfrage anfrage = new KonsultationdatenAnfrage();
				
				try {
					Konsultationsuchen dialog = new Konsultationsuchen();
					dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
					dialog.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	KseServiceLocator ksl = new KseServiceLocator();
	SuchFilter sfl = new SuchFilter();
	private JTextField tfKonsSearch;
	private JTable tblKonsultation;
	private JTable table;

	/**
	 * Create the dialog.
	 */
	public Konsultationsuchen() {
		getContentPane().setBackground(new Color(255, 255, 204));
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(null);
		
		JButton btnZurckZumHauptmen = new JButton("Zur\u00FCck zum Hauptmen\u00FC");
		btnZurckZumHauptmen.setBackground(new Color(153, 204, 204));
		btnZurckZumHauptmen.setForeground(new Color(0, 0, 153));
		btnZurckZumHauptmen.setFont(new Font("Lucida Bright", Font.PLAIN, 11));
		btnZurckZumHauptmen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Konsultationverwalten newWindow = new Konsultationverwalten();
				newWindow.setVisible(true);
			}
		});
		btnZurckZumHauptmen.setBounds(216, 238, 218, 23);
		btnZurckZumHauptmen.setBounds(216, 238, 218, 23);
		btnZurckZumHauptmen.setBounds(216, 238, 218, 23);
		btnZurckZumHauptmen.setBounds(216, 238, 218, 23);
		btnZurckZumHauptmen.setBounds(216, 238, 218, 23);
		getContentPane().add(btnZurckZumHauptmen);
		
		JButton btnSuchen = new JButton("Suchen");
		btnSuchen.setBackground(new Color(153, 204, 204));
		btnSuchen.setForeground(new Color(0, 0, 153));
		btnSuchen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try{
				IKseService fus = ksl.getkse_17();
				//SuchFilter sf = sfl.get
				//Konsultation konsultation = fus.doKonsultation(Dialogaufbauen.cin, Dialogaufbauen.d, Dialogaufbauen.ecardnummer, svtCode, Dialogaufbauen.anspruchid, fachgebietsCode, behandlungsfallCode, nacherfassungsgrundCode, behandlungsdatum, forceExecution, Dialogaufbauen.cardid);
				//Konsultation[] kons = fus.getKonsultationsdaten(Dialogaufbauen.d, , "ALLE", "KVT");
				}catch(Exception d){
					d.printStackTrace();
				}
				
			}
		});
		btnSuchen.setFont(new Font("Lucida Bright", Font.PLAIN, 11));
		btnSuchen.setBounds(216, 11, 89, 23);
		getContentPane().add(btnSuchen);
		
		tfKonsSearch = new JTextField();
		tfKonsSearch.setForeground(new Color(0, 0, 204));
		tfKonsSearch.setBounds(10, 12, 86, 20);
		getContentPane().add(tfKonsSearch);
		tfKonsSearch.setColumns(10);
		
		Object rowData[][] = { { Dialogaufbauen.d, "Row1-Column2", "Row1-Column3" },
		        { "Row2-Column1", "Row2-Column2", "Row2-Column3" } };
		Object columnNames[] = { "KonsultationID", "Behandlungsfall", "Version" };
		
		
		JTable tblKonsultation = new JTable(rowData, columnNames);
		tblKonsultation.setBackground(new Color(255, 255, 204));
		tblKonsultation.setBounds(10, 51, 414, 150);
		getContentPane().add(tblKonsultation);
		
		

	}
}
