package at.spengergasse.model;

import java.io.Serializable;

import at.chipkarte.client.base.soap.Card;
import at.chipkarte.client.vdas.soap.VersichertendatenAbfrageErgebnis;

public class Model_Dialogaufbauen implements Serializable {
	
	public static String pd = "";
	public static Card pcardid;
	public static String pcin;
	public static String pecardnummer = "";
	public static String panspruchid = "";
	public static VersichertendatenAbfrageErgebnis psvtid;
	public static String pvorname = "";
	public static String pnachname = "";
	public static String preaId;
	public static String pselectedRea;
	public static String psvnummer;
	
	public Model_Dialogaufbauen(){
		
	}
	
	public Model_Dialogaufbauen(String Mdp, Card Mpcardid, String Mpcin, String Mpecardnummer, String Mpanspruchid, 
			VersichertendatenAbfrageErgebnis Mpsvtid, String Mpvorname, String Mpnachname, String MpreaId, String MpselectedRea,
			String Mpsvnummer){
		
		pd = Mdp;
		pcardid = Mpcardid;
		pcin = Mpcin;
		pecardnummer = Mpecardnummer;
		panspruchid = Mpanspruchid;
		psvtid = Mpsvtid;
		pvorname = Mpvorname;
		pnachname = Mpnachname;
		preaId = MpreaId;
		pselectedRea = MpselectedRea;
		psvnummer = Mpsvnummer;
	}

	public static String getPd() {
		return pd;
	}

	public static void setPd(String pd) {
		Model_Dialogaufbauen.pd = pd;
	}

	public static Card getPcardid() {
		return pcardid;
	}

	public static void setPcardid(Card pcardid) {
		Model_Dialogaufbauen.pcardid = pcardid;
	}

	public static String getPcin() {
		return pcin;
	}

	public static void setPcin(String pcin) {
		Model_Dialogaufbauen.pcin = pcin;
	}

	public static String getPecardnummer() {
		return pecardnummer;
	}

	public static void setPecardnummer(String pecardnummer) {
		Model_Dialogaufbauen.pecardnummer = pecardnummer;
	}

	public static String getPanspruchid() {
		return panspruchid;
	}

	public static void setPanspruchid(String panspruchid) {
		Model_Dialogaufbauen.panspruchid = panspruchid;
	}

	public static VersichertendatenAbfrageErgebnis getPsvtid() {
		return psvtid;
	}

	public static void setPsvtid(VersichertendatenAbfrageErgebnis psvtid) {
		Model_Dialogaufbauen.psvtid = psvtid;
	}

	public static String getPvorname() {
		return pvorname;
	}

	public static void setPvorname(String pvorname) {
		Model_Dialogaufbauen.pvorname = pvorname;
	}

	public static String getPnachname() {
		return pnachname;
	}

	public static void setPnachname(String pnachname) {
		Model_Dialogaufbauen.pnachname = pnachname;
	}

	public static String getPreaId() {
		return preaId;
	}

	public static void setPreaId(String preaId) {
		Model_Dialogaufbauen.preaId = preaId;
	}

	public static String getPselectedRea() {
		return pselectedRea;
	}

	public static void setPselectedRea(String pselectedRea) {
		Model_Dialogaufbauen.pselectedRea = pselectedRea;
	}

	public static String getPsvnummer() {
		return psvnummer;
	}

	public static void setPsvnummer(String psvnummer) {
		Model_Dialogaufbauen.psvnummer = psvnummer;
	}

}
